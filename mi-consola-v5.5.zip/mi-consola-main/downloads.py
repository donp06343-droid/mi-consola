"""
Mi Consola - Cola de descargas
"""
import json
import os
import shutil
import subprocess
import tempfile
import time
import zipfile
import threading
import urllib.request
import urllib.error
import urllib.parse

from config import JUEGOS, BASE

cola = []


def nombre_archivo(url, n):
    return os.path.basename(urllib.parse.unquote(urllib.parse.urlparse(url).path)) or f"archivo_{n}"


def _extraer_plano(zip_path, destino):
    """Extrae el zip en destino. Si todo viene dentro de UNA carpeta raiz,
    la quita para que el .exe quede directamente en destino."""
    with zipfile.ZipFile(zip_path) as z:
        nombres = [n for n in z.namelist() if n and not n.endswith("/")]
        raices = {n.split("/", 1)[0] for n in nombres}
        quitar = len(raices) == 1 and all("/" in n for n in nombres)
        base = os.path.realpath(destino)
        for info in z.infolist():
            rel = info.filename
            if quitar:
                rel = rel.split("/", 1)[1] if "/" in rel else ""
            if not rel:
                continue
            out = os.path.realpath(os.path.join(destino, rel))
            if not _dentro(base, out):            # evita rutas fuera de destino
                continue
            if info.is_dir():
                os.makedirs(out, exist_ok=True)
            else:
                os.makedirs(os.path.dirname(out), exist_ok=True)
                with z.open(info) as src, open(out, "wb") as dst:
                    shutil.copyfileobj(src, dst)


def _dentro(base, ruta):
    """True si ruta (ya resuelta) queda dentro de base. Evita el falso positivo
    de startswith ('/a/b' vs '/a/bc')."""
    try:
        return os.path.commonpath([base, ruta]) == base
    except ValueError:
        return False


def _aplanar_desde(tmp, destino):
    """Mueve el contenido de tmp a destino; si tmp tiene UNA sola carpeta, la salta."""
    base = os.path.realpath(destino)
    entradas = os.listdir(tmp)
    raiz = tmp
    if len(entradas) == 1 and os.path.isdir(os.path.join(tmp, entradas[0])):
        raiz = os.path.join(tmp, entradas[0])
    for r, _ds, fs in os.walk(raiz):
        for f in fs:
            origen = os.path.join(r, f)
            out = os.path.realpath(os.path.join(destino, os.path.relpath(origen, raiz)))
            if not _dentro(base, out):
                continue
            os.makedirs(os.path.dirname(out), exist_ok=True)
            shutil.move(origen, out)


def _buscar_7z():
    for c in ("7z", "7z.exe", "7za", "7za.exe"):
        p = shutil.which(c)
        if p:
            return p
    for c in (os.path.join(BASE, "tools", "7z.exe"), os.path.join(BASE, "tools", "7za.exe"),
              r"C:\Program Files\7-Zip\7z.exe"):
        if os.path.exists(c):
            return c
    return None


def _extraer_7z(arc_path, destino):
    """Extrae .7z: primero py7zr, si no 7z.exe (PATH, BASE/tools o Program Files)."""
    os.makedirs(destino, exist_ok=True)
    tmp = tempfile.mkdtemp(prefix="mc7z_", dir=os.path.dirname(os.path.abspath(destino)))
    try:
        try:
            import py7zr  # type: ignore
        except ImportError:
            py7zr = None
        if py7zr:
            with py7zr.SevenZipFile(arc_path, mode="r") as z:
                z.extractall(path=tmp)
        else:
            exe = _buscar_7z()
            if not exe:
                raise RuntimeError("Falta soporte .7z: pip install py7zr, o 7z.exe en PATH o tools/")
            r = subprocess.run([exe, "x", "-y", f"-o{tmp}", arc_path],
                               capture_output=True, text=True, timeout=900)
            if r.returncode != 0:
                raise RuntimeError(f"7z fallo ({r.returncode}): {(r.stderr or r.stdout or '')[:80]}")
        _aplanar_desde(tmp, destino)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _extraer_archivo(path, destino_fijo, carpeta, nombre):
    """Extrae .zip o .7z. Con destino_fijo (emuladores) aplana la carpeta raiz."""
    low = path.lower()
    if low.endswith(".zip"):
        if destino_fijo:
            _extraer_plano(path, destino_fijo)
        else:
            zipfile.ZipFile(path).extractall(os.path.join(carpeta, nombre))
    elif low.endswith(".7z"):
        _extraer_7z(path, destino_fijo or os.path.join(carpeta, nombre))
    else:
        return
    os.remove(path)


# ---------------------------------------------------------------------------
# Formato legible
# ---------------------------------------------------------------------------
def fmt_bytes(n):
    n = float(n or 0)
    for u in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or u == "TB":
            return f"{n:.0f} {u}" if u == "B" else f"{n:.1f} {u}"
        n /= 1024


def fmt_vel(bps):
    return f"{fmt_bytes(bps)}/s" if bps and bps >= 1 else "-"


def fmt_eta(seg):
    if seg is None:
        return "-"
    seg = int(seg)
    h, r = divmod(seg, 3600)
    m, s = divmod(r, 60)
    if h:
        return f"{h} h {m:02d} min"
    if m:
        return f"{m} min {s:02d} s"
    return f"{s} s"


def eta_item(it):
    """Segundos restantes de la parte actual, o None si no se puede estimar."""
    if it.get("estado") != "bajando" or not it.get("total") or it.get("vel", 0) < 1:
        return None
    return max(0, (it["total"] - it["hecho"]) / it["vel"])


_libre = {"t": 0.0, "v": None}


def espacio_libre(ruta=None):
    """Bytes libres en el disco de destino (cacheado 3 s: se llama en cada frame)."""
    if time.time() - _libre["t"] < 3:
        return _libre["v"]
    try:
        r = ruta or JUEGOS
        while r and not os.path.exists(r):
            r = os.path.dirname(r)
        _libre["v"] = shutil.disk_usage(r or BASE).free
    except Exception:
        _libre["v"] = None
    _libre["t"] = time.time()
    return _libre["v"]


# ---------------------------------------------------------------------------
# Limite de velocidad (para no ahogar la red mientras jugas)
# ---------------------------------------------------------------------------
LIMITES_MBS = [0, 2, 5, 10, 25]      # 0 = sin limite
_limite = {"i": 0}


def limite_bps():
    return LIMITES_MBS[_limite["i"]] * 1024 * 1024


def ciclar_limite():
    _limite["i"] = (_limite["i"] + 1) % len(LIMITES_MBS)
    return texto_limite()


def texto_limite():
    v = LIMITES_MBS[_limite["i"]]
    return "sin limite" if v == 0 else f"{v} MB/s"


def velocidad_total():
    return sum(i.get("vel", 0) for i in cola if i["estado"] == "bajando")


# ---------------------------------------------------------------------------
# Control de items (pausa / reanudar / reintentar / quitar)
# ---------------------------------------------------------------------------
def pausar(it):
    if it["estado"] == "bajando" or it["estado"] == "reintentando":
        it["pausa"] = True             # el trabajador lo frena en el proximo bloque
    elif it["estado"] == "en cola":
        it["estado"] = "pausado"
    guardar_cola()


def reanudar(it):
    if it.get("pausa"):                # pidio pausa pero aun no frena: cancelar la pausa
        it["pausa"] = False
    elif it["estado"] in ("pausado", "error"):
        it["estado"], it["error"], it["pausa"] = "en cola", "", False
    guardar_cola()


def alternar_pausa(it):
    if it["estado"] in ("bajando", "reintentando", "en cola") and not it.get("pausa"):
        pausar(it)
    else:
        reanudar(it)


def _borrar_parciales(it):
    for t in (it.get("tmp"),):
        try:
            if t and os.path.exists(t):
                os.remove(t)
        except OSError:
            pass


def quitar(it):
    """Quita de la cola. Si esta bajando, lo cancela (borra el parcial)."""
    if it["estado"] in ("bajando", "reintentando"):
        it["cancelar"] = True          # el trabajador limpia y lo saca
        return
    if it["estado"] != "listo":
        _borrar_parciales(it)
    if it in cola:
        cola.remove(it)
    guardar_cola()


def limpiar_completadas():
    n = 0
    for it in [i for i in cola if i["estado"] == "listo"]:
        cola.remove(it)
        n += 1
    guardar_cola()
    return n


# ---------------------------------------------------------------------------
# Persistencia: la cola sobrevive a cerrar el programa (los .part se reanudan)
# ---------------------------------------------------------------------------
COLA_JSON = os.path.join(BASE, "cola_descargas.json")
_CAMPOS = ("nombre", "sistema", "destino", "urls", "listos", "parte")


def guardar_cola():
    try:
        datos = [{**{k: i.get(k) for k in _CAMPOS}, "estado": i["estado"]} for i in cola if i["estado"] != "listo"]
        os.makedirs(BASE, exist_ok=True)
        tmp = COLA_JSON + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(datos, f, ensure_ascii=False)
        os.replace(tmp, COLA_JSON)
    except Exception:
        pass


def cargar_cola():
    try:
        with open(COLA_JSON, encoding="utf-8") as f:
            for d in json.load(f):
                it = _nuevo_item(d["urls"], d["sistema"], d["nombre"], d.get("destino"))
                it["listos"] = d.get("listos") or []
                it["parte"] = d.get("parte") or 1
                it["estado"] = "pausado"     # nunca arranca solo: el usuario decide
                try:                         # donde quedo el parcial (para poder borrarlo)
                    carp = it["destino"] or os.path.join(JUEGOS, it["sistema"])
                    it["tmp"] = os.path.join(carp, nombre_archivo(it["urls"][it["parte"] - 1], 0)) + ".part"
                except Exception:
                    pass
                cola.append(it)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Trabajador
# ---------------------------------------------------------------------------
_FATAL = (400, 401, 403, 404, 410)


def _descargar_parte(item, url, dest):
    """Baja una URL a dest (con .part y Range). Reintenta solo ante cortes de red."""
    tmp = dest + ".part"
    item["tmp"] = tmp
    intentos = 0
    while True:
        try:
            tengo = os.path.getsize(tmp) if os.path.exists(tmp) else 0
            req = urllib.request.Request(url, headers={
                "Range": f"bytes={tengo}-",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) MiConsola/5.3",
            })
            with urllib.request.urlopen(req, timeout=30) as r:
                largo = int(r.headers.get("Content-Length") or 0)
                if r.status == 206:
                    modo, item["total"] = "ab", tengo + largo
                else:                                   # el servidor no soporta Range
                    modo, tengo, item["total"] = "wb", 0, largo
                item["hecho"] = tengo
                item["estado"], item["error"] = "bajando", ""
                with open(tmp, modo) as f:
                    t_ult, b_ult = time.time(), item["hecho"]
                    while True:
                        if item.get("pausa") or item.get("cancelar"):
                            raise InterruptedError
                        t0 = time.time()
                        bloque = r.read(1 << 17)
                        if not bloque:
                            break
                        f.write(bloque)
                        item["hecho"] += len(bloque)
                        ahora = time.time()
                        if ahora - t_ult >= 0.3:         # velocidad suavizada
                            inst = (item["hecho"] - b_ult) / (ahora - t_ult)
                            item["vel"] = inst if not item["vel"] else item["vel"] * 0.7 + inst * 0.3
                            t_ult, b_ult = ahora, item["hecho"]
                        lim = limite_bps()
                        if lim:
                            espera = len(bloque) / lim - (time.time() - t0)
                            if espera > 0:
                                time.sleep(min(espera, 1.0))
            if item["total"] and item["hecho"] < item["total"]:
                raise ConnectionError("conexion cortada")
            break
        except InterruptedError:
            raise
        except urllib.error.HTTPError as e:
            if e.code == 416 and os.path.exists(tmp):    # el parcial ya estaba completo
                break
            if e.code in _FATAL:
                raise
            intentos = _esperar_reintento(item, e, intentos)
        except OSError as e:
            if isinstance(e, (FileNotFoundError, PermissionError)) or getattr(e, "errno", None) == 28:
                raise                                    # disco lleno / sin permisos: no reintentar
            intentos = _esperar_reintento(item, e, intentos)
        except Exception as e:
            intentos = _esperar_reintento(item, e, intentos)
    os.replace(tmp, dest)


def _esperar_reintento(item, e, intentos):
    intentos += 1
    if intentos > 5:
        raise e
    item["estado"], item["vel"] = "reintentando", 0
    item["error"] = f"sin conexion, reintento {intentos}/5"
    fin = time.time() + min(30, 2 * intentos * intentos)
    while time.time() < fin:
        if item.get("pausa") or item.get("cancelar"):
            raise InterruptedError
        time.sleep(0.2)
    return intentos


def trabajador():
    ult_guardado = 0
    while True:
        item = next((i for i in cola if i["estado"] == "en cola"), None)
        if not item:
            time.sleep(0.5)
            if time.time() - ult_guardado > 5:
                guardar_cola()
                ult_guardado = time.time()
            continue
        item["estado"], item["pausa"], item["error"] = "bajando", False, ""
        try:
            destino_fijo = item.get("destino")          # ej: carpeta de un emulador
            carpeta = destino_fijo or os.path.join(JUEGOS, item["sistema"])
            os.makedirs(carpeta, exist_ok=True)
            for n, url in enumerate(item["urls"]):
                if n < len(item["listos"]):
                    continue
                item["parte"], item["vel"] = n + 1, 0
                dest = os.path.join(carpeta, nombre_archivo(url, n))
                _descargar_parte(item, url, dest)
                if dest.lower().endswith((".zip", ".7z")):
                    item["estado"] = "extrayendo"
                    try:
                        _extraer_archivo(dest, destino_fijo, carpeta, item["nombre"])
                    except Exception as e:
                        item["error"] = f"No se pudo extraer: {str(e)[:70]}"
                item["listos"].append(dest)
            item["vel"] = 0
            item["estado"] = "error" if item.get("error", "").startswith("No se pudo extraer") else "listo"
        except InterruptedError:
            item["vel"] = 0
            if item.get("cancelar"):
                _borrar_parciales(item)
                if item in cola:
                    cola.remove(item)
            else:
                item["estado"], item["pausa"] = "pausado", False
        except Exception as e:
            item["vel"] = 0
            item["estado"] = "error"
            item["error"] = str(e)[:100]
        guardar_cola()


def _nuevo_item(urls, sistema, nombre, destino=None):
    return {
        "nombre": nombre,
        "sistema": sistema,
        "destino": destino,
        "urls": urls,
        "listos": [],
        "estado": "en cola",
        "parte": 1,
        "hecho": 0,
        "total": 0,
        "vel": 0,
        "pausa": False,
        "cancelar": False,
        "tmp": None,
        "error": "",
    }


def agregar_enlaces(texto, sistema, nombre=None, destino=None):
    urls = [l.strip() for l in texto.splitlines() if l.strip().lower().startswith(("http://", "https://"))]
    if not urls:
        return False
    nombre = nombre or os.path.splitext(nombre_archivo(urls[0], 0))[0]
    cola.append(_nuevo_item(urls, sistema, nombre, destino))
    guardar_cola()
    return True


def leer_portapapeles():
    try:
        import tkinter
        r = tkinter.Tk()
        r.withdraw()
        t = r.clipboard_get()
        r.destroy()
        return t
    except Exception:
        return ""


# Arrancar: restaurar cola guardada y lanzar el trabajador
cargar_cola()
threading.Thread(target=trabajador, daemon=True).start()
