# Roadmap - Mi Consola

Meta: pasar de un launcher a un **sistema de consola** (PC) y luego a una **consola fisica**.

## Fase 1 - Launcher completo (actual, v5.x)
- [x] Biblioteca, portadas, favoritos, tienda con categorias
- [x] Modo kiosk (Capa 1)
- [x] shadPS4: instalar, detectar, lanzar
- [x] Instalador generico de emuladores (+ .7z) - v5.2 (falta probar en PC real)
- [ ] Pantalla de estado del sistema
- [ ] Tests + CI
- [x] Centro de descargas: pausa, velocidad, ETA, limite, reintentos (v5.3)
- [x] Estadisticas por juego + pantalla general + portadas para Epic/GOG por nombre (v5.5)
- [ ] Catalogo grande (100.000+) con portadas: SQLite + lista oficial de Steam + cache lazy
- [x] Tiendas conectadas: biblioteca unificada Steam + Epic + GOG, lanzar por protocolo (v5.4)
- [ ] Detectar juegos de Xbox/Microsoft Store, EA App, Ubisoft Connect, Battle.net, itch.io (agregar a stores.PROVEEDORES)
- [ ] Biblioteca completa (incluye NO instalados) via cuenta: Steam GetOwnedGames, Epic/GOG via legendary/gogdl
- [ ] Filtro y lista de multijugador local
- [ ] Navegacion total con mando

## Fase 2 - Consola OS en PC
- [ ] Arranque directo al launcher (reemplazo de shell de Windows) con recuperacion
- [ ] Autoarranque, login automatico, energia (suspender/apagar desde el menu)
- [ ] Actualizaciones automaticas desde GitHub (con rollback)
- [ ] Ajustes de sistema desde la UI: wifi, bluetooth, audio, resolucion
- [ ] Instalador / USB booteable
- [ ] Evaluar base Linux ligera (Steam Deck style) vs Windows kiosk

## Fase 3 - Consola fisica
- [ ] Definir hardware objetivo (mini-PC / SBC) y requisitos para PS2/PS3/Switch/PS4
- [ ] Imagen de sistema reproducible
- [ ] Controles, refrigeracion, carcasa
- [ ] Licencias: solo software libre/legal, sin BIOS/firmware/juegos incluidos
