@echo off
REM ==========================================================
REM  Mi Consola - RECUPERACION
REM  Usalo si despues de cerrar la consola la barra de tareas o
REM  el escritorio de Windows no vuelven a aparecer.
REM ==========================================================
echo Restaurando el escritorio de Windows...

REM 1) Borrar el archivo de estado de una ejecucion anterior
del "%TEMP%\mi_consola_kiosk.lock" >nul 2>&1

REM 2) Reiniciar el explorador: recrea la barra de tareas visible.
taskkill /f /im explorer.exe >nul 2>&1
start "" explorer.exe

echo Listo. Si el escritorio no aparece en unos segundos, pulsa Ctrl+Shift+Esc,
echo elige "Ejecutar nueva tarea" y escribe: explorer.exe
timeout /t 5 >nul
