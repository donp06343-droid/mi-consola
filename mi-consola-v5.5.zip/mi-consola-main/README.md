# Mi Consola v5.5 (shadPS4 + emuladores + descargas + tiendas + estadisticas)

Lanzador a pantalla completa + centro de descargas de juegos (emuladores + PC).

## Caracteristicas

- Frontend de emulacion (NES, SNES, N64, PS1, PS2, Switch, etc.)
- Lanzador de juegos de PC (Steam, Epic, carpetas genericas)
- **Portadas automaticas mejoradas** (Steam CDN + Libretro + matching inteligente)
- Favoritos, busqueda, ordenamiento
- Centro de descargas + tienda de juegos gratis/legales
- Controles configurables (teclado + gamepad)
- Lobby con estrellas parallax

## Estructura modular

```
mi-consola/
├── main.py              # Punto de entrada
├── config.py            # Rutas, colores, sistemas, emuladores
├── covers.py            # Sistema de portadas (mejorado)
├── library.py           # Escaneo de biblioteca + favoritos
├── launcher.py          # Lanzamiento de juegos/emuladores
├── downloads.py         # Cola de descargas
├── store.py             # Tienda (categorias) + resolver de enlaces
├── ps4.py               # shadPS4: lector param.sfo, icon0, deteccion de juegos
├── controls.py          # Controles teclado/joystick
├── ui/
│   ├── stars.py         # Campo de estrellas
│   └── cards.py         # Tarjetas de juegos
├── consoleos/           # Capa de sistema (Consola OS)
│   ├── modes.py         # NORMAL | CONSOLE
│   ├── settings.py      # consoleos.json + PIN
│   ├── log.py           # logs rotativos
│   └── shell/           # Capa 1: Shell / Kiosk
│       ├── controller.py    # orquestador (instancia `kiosk`)
│       ├── winapi.py        # ctypes (ventanas, foco, procesos)
│       ├── taskbar.py       # ocultar/restaurar barra de tareas
│       ├── keyhook.py       # bloqueo de atajos (hook global)
│       ├── escape.py        # combinacion secreta (teclado y mando)
│       ├── focus.py         # juego en curso + devolver el foco
│       └── system_menu.py   # menu Apagar/Reiniciar/Escritorio + PIN
├── tools/               # .bat de inicio, PIN y recuperacion
├── requirements.txt
└── README.md
```

## Requisitos

```bash
pip install pygame
# Opcional:
pip install pywebview
```

## Uso

```bash
python main.py
```

La carpeta base por defecto es `D:\\Emulacion` (configurable con `MI_CONSOLA_BASE`).

## Teclas principales

| Tecla | Accion |
|-------|--------|
| Flechas / WASD | Mover |
| Enter / Espacio | Jugar |
| F | Favorito |
| / o F3 | Buscar |
| O | Cambiar orden |
| Tab | Descargas |
| T | Tienda |
| R | Re-escanear |
| C | Controles |
| M | Spotify |
| Esc | Volver / Salir |

## Mejoras v5 (portadas)

- Matching de nombres mas inteligente (ignora regiones, codigos, articulos)
- Score de similitud para elegir la mejor imagen local
- Prioridad clara: Steam cache → Covers/ → junto a ROM → descarga
- Placeholders mas limpios
- Descarga concurrente controlada

## Version

v5.2-emuladores


## Modo Consola OS (Capa 1: Shell / Kiosk)

```bash
python main.py                  # modo normal (como siempre)
python main.py --mode console   # modo consola (kiosk)
```

O con doble clic: `tools\iniciar_modo_consola.bat`.

En modo consola:

- Se oculta la barra de tareas (y vuelve sola al salir).
- Se bloquean la tecla Windows, Alt+Tab, Alt+Esc, Ctrl+Esc y Ctrl+Shift+Esc.
- Alt+F4 esta bloqueado sobre el launcher, pero **sigue funcionando dentro de
  juegos y emuladores** para poder cerrar uno colgado.
- Al lanzar un juego el launcher cede el primer plano; al cerrarlo, lo recupera.
- Esc / B en la pantalla de inicio abre el **menu del sistema**: continuar,
  reiniciar, apagar y salir al escritorio (este ultimo pide PIN).

### Salida secreta

Mantener **Ctrl+Shift+F12** durante 3 s (teclado) o **Select+Start+L1+R1**
(mando) abre la pantalla de PIN aunque un juego tenga el foco.
PIN por defecto: `0000`. Cambiarlo con `tools\cambiar_pin.bat`.

### Configuracion

Se guarda en `<BASE>\consoleos.json` (se crea sola la primera vez). Opciones:
`mode`, `hide_taskbar`, `block_keys`, `force_topmost`, `allow_altf4_in_games`,
`allow_exit_to_desktop`, `escape_keys`, `escape_pad_buttons`,
`escape_hold_seconds`. Los logs estan en `<BASE>\logs\consoleos.log`.

### Si algo sale mal

Ejecuta `tools\recovery.bat`: restaura la barra de tareas y el explorador.
Arrancar `python main.py` en modo normal tambien limpia el estado de una
sesion anterior que haya terminado de forma abrupta.

### Limites conocidos

- Ctrl+Alt+Supr y Win+L no se pueden bloquear desde ningun programa.
- Es un kiosk "de uso domestico", no un sandbox de seguridad.
- Abrir paginas de la tienda usa el navegador/webview del sistema; se cierra con Alt+F4.


## Novedades v5.1

### shadPS4 (PS4)

- **Instalacion con un Enter**: Tienda (T) > categoria *Emuladores* > *shadPS4*.
  Baja el ultimo release de GitHub (prefiere el build Qt, con GUI para instalar PKG)
  y lo extrae en `<BASE>\shadPS4\` sin carpeta intermedia.
- **Deteccion de juegos**: cualquier carpeta con `eboot.bin` dentro de
  `Juegos\PS4\` (hasta 3 niveles). El nombre real sale de `sce_sys\param.sfo`
  y la portada de `sce_sys\icon0.png`.
- **Lanzamiento**: `shadPS4.exe -g <eboot.bin>`; en modo consola agrega `-f true`
  (pantalla completa). Si tu `consola_config.json` ya trae argumentos propios, se respetan.
- **.pkg**: se listan como `[PKG]`. shadPS4 no los ejecuta directo: instalalos desde
  shadPS4 (Archivo > Instalar PKG) y re-escanea con R.
- Solo juegos que tu mismo volcaste de tu consola. No se incluyen juegos ni firmware.

### Tienda ampliada

- 51 titulos en categorias (Emuladores, Shooter, Estrategia, Carreras, Plataformas,
  Aventura/RPG, Free-to-play). Izquierda/derecha cambia de categoria.
- Todo es software libre, freeware o free-to-play oficial. Si un release de GitHub
  no se puede resolver, abre la pagina oficial de descarga.
- Las descargas de emuladores pueden ir a una carpeta fija (`destino`) y los zip
  se extraen de forma segura (sin rutas fuera del destino).

## Novedades v5.2

- **Instalador de emuladores** en la Tienda (categoria Emuladores): shadPS4, PPSSPP, DuckStation,
  PCSX2, RPCS3, mGBA, melonDS, Cemu y Azahar (3DS). Dolphin y Eden abren su pagina oficial.
- **Soporte .7z**: `pip install py7zr`, o 7-Zip en el PATH / `tools\` / Program Files.
- **Citra y Ryujinx** estan discontinuados: 3DS usa Azahar y Switch usa Eden por defecto.
  Si el emulador configurado no existe, el launcher prueba alternativas y busca el .exe solo.
- Tecla **G**: abre la GUI de shadPS4 (instalar PKG).
- Detalle de lo verificado y lo pendiente: `VERIFICACION.md`.

## Novedades v5.3 - Centro de descargas

- **Velocidad en vivo, % y tiempo restante** por descarga; velocidad total y espacio libre en disco arriba.
- **Pausar / seguir (P)** sin perder lo bajado (reanuda con Range). **Cancelar (Supr)** borra el parcial.
- **Limite de velocidad (L)**: sin limite / 2 / 5 / 10 / 25 MB/s, para no ahogar la red mientras jugas.
- **Reintentos automaticos** si se corta la conexion (hasta 5, reanudando donde quedo).
- **La cola sobrevive** a cerrar el programa (queda en pausa; vos la retomas). Archivo: `cola_descargas.json`.
- **X** limpia las completadas. Si el servidor no soporta reanudar, reinicia esa parte.
- Una descarga a la vez (a proposito: estable). Las descargas de Steam/Epic las maneja su propio cliente.

## Novedades v5.4 - Tiendas conectadas

- **Biblioteca unificada** (`stores.py`): juegos instalados de **Steam, Epic y GOG** aparecen juntos, leyendo
  archivos locales. Sin cuentas, sin claves, sin contrasenas.
- **Epic se lanza por su launcher** (`com.epicgames.launcher://apps/...`), no por el .exe suelto (asi funciona el login/DRM).
  Se ignoran DLC, motor UE e instalaciones incompletas. Steam: solo juegos instalados por completo, en todos tus discos.
- **Categoria Tiendas** en la Tienda (T): abre Steam / Epic / GOG / Microsoft Store en su cliente (no en un navegador).
  Los juegos free-to-play de Steam abren su pagina *dentro de Steam*. Si no esta el cliente, abre la web oficial.
- Comprar sigue pasando por el cliente de cada tienda (no existe checkout embebible para terceros).
- Falta: Xbox/Microsoft Store, EA App, Ubisoft Connect, Battle.net, itch.io y biblioteca completa por cuenta.
  Para sumar una tienda: escribir `detectar_xxx()` en `stores.py` y agregarla a `PROVEEDORES`.

## Novedades v5.5 - Portadas y estadisticas

- **Panel del juego** (abajo a la derecha): tiempo jugado, ultimas 2 semanas, ultima vez, cantidad de inicios y tamano.
- **Steam**: tiempo real leido de los archivos de Steam (sin claves). **Emuladores / GOG / PS4 / .exe**: la consola mide el
  tiempo mientras el juego esta abierto. **Epic**: solo inicios y ultima vez (Epic no deja el tiempo en archivos locales).
- **H = Estadisticas generales**: juegos por tienda, tiempo total, mas jugados y recientes.
- **Portadas para Epic, GOG y PC**: busca el juego por nombre en Steam y baja su portada (coincidencia estricta: "Portal" no
  toma "Portal 2"). Resultado cacheado en `cache_appids.json`. Si no hay match, queda el placeholder.
- **SteamGridDB (opcional)**: si creas `claves.json` con `{"steamgriddb": "TU_CLAVE"}` (clave gratis), se usa como ultimo recurso.
  Nunca pegues claves en chats; van solo en ese archivo local.
- Estadisticas guardadas en `estadisticas.json`.
