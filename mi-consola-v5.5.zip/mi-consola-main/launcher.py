"""
Mi Consola - Lanzador de juegos y emuladores
"""

import os
import re
import sys
import subprocess
import webbrowser

from config import BASE, CFG, EMU_DEFECTO, EMU_ALTERNATIVAS
from library import _es_rom_valida
import ps4
import stats
import stores
from consoleos.shell import kiosk


_NO_EXE = re.compile(r"(?i)unins|crash|redist|vc_?|setup|install|repair|helper|updater|bootstrap")


def _resolver_exe(sis: str, exe_path: str):
    """Devuelve un ejecutable existente para el sistema, o None.
    1) el configurado, 2) alternativas conocidas, 3) un .exe parecido en la carpeta del emulador."""
    cands = [exe_path] + [os.path.join(BASE, *p) for p in EMU_ALTERNATIVAS.get(sis, [])]
    for c in cands:
        if os.path.exists(c):
            return c
    for c in cands:
        d = os.path.dirname(c)
        pista = re.sub(r"[^a-z0-9]", "", os.path.splitext(os.path.basename(c))[0].lower())[:5]
        if not pista or not os.path.isdir(d):
            continue
        mejor, tam = None, 0
        for r, ds, fs in os.walk(d):
            if r[len(d):].count(os.sep) >= 2:
                ds[:] = []
            for f in fs:
                if f.lower().endswith(".exe") and not _NO_EXE.search(f) and pista in re.sub(r"[^a-z0-9]", "", f.lower()):
                    p = os.path.join(r, f)
                    t = os.path.getsize(p)
                    if t > tam:
                        mejor, tam = p, t
        if mejor:
            return mejor
    return None


def abrir_uri(uri: str) -> str:
    """Abre un protocolo de tienda con el cliente instalado (sin navegador).
    Devuelve "" si salio bien o un mensaje de error."""
    try:
        if sys.platform == "win32":
            os.startfile(uri)
        else:
            webbrowser.open(uri)           # solo para desarrollo en Linux/Mac
        return ""
    except Exception:
        nombre = uri.split("://", 1)[0]
        return f"No pude abrir '{nombre}'. Esta instalado el cliente de esa tienda?"


def _lanzado(proc, clave=None):
    """Avisa al kiosk y mide el tiempo jugado (si se conoce la clave del juego)."""
    kiosk.game_launched(proc)
    if clave:
        stats.seguir_proceso(clave, proc)


def jugar(sis: str, ruta: str, cfg: dict, clave: str = None) -> str:
    """
    Lanza el juego/emulador.
    Devuelve string vacio si todo ok, o mensaje de error.
    """
    # Protocolos de tiendas (steam://, com.epicgames.launcher://, ...)
    if stores.es_uri(ruta):
        msg = abrir_uri(ruta)
        if not msg:
            kiosk.external_launched()
        return msg

    # Juegos nativos PC / Epic / Steam / Xbox
    if sis in ("PC", "Epic", "Steam", "Xbox", "GOG"):
        exe = ruta
        if os.path.isdir(ruta):
            nombre_carpeta = os.path.basename(ruta).lower().replace(" ", "").replace("-", "").replace("_", "")
            candidatos = []
            for r, _, fs in os.walk(ruta):
                depth = r[len(ruta):].count(os.sep)
                if depth > 3:
                    continue
                for f in fs:
                    fl = f.lower()
                    if not fl.endswith(".exe"):
                        continue
                    if re.search(r"(?i)unins|crash|redist|vc_?|setup|install|repair|helper|updater|bootstrap|notification|dxsetup|vcredist|oalinst|physx|dotnet", fl):
                        continue
                    p = os.path.join(r, f)
                    try:
                        tam = os.path.getsize(p)
                    except Exception:
                        continue
                    score = tam
                    base_name = fl[:-4].replace(" ", "").replace("-", "").replace("_", "")
                    if nombre_carpeta and (nombre_carpeta in base_name or base_name in nombre_carpeta):
                        score += 50_000_000
                    if depth <= 1:
                        score += 5_000_000
                    candidatos.append((score, p))
            if not candidatos:
                return "No encontre el .exe del juego."
            candidatos.sort(reverse=True)
            exe = candidatos[0][1]
        try:
            cwd = os.path.dirname(exe) or None
            proc = subprocess.Popen([exe], cwd=cwd)
        except Exception as e:
            return f"Error al lanzar: {e}"
        _lanzado(proc, clave)
        return ""

    # PS4 -> shadPS4 (flujo propio)
    if sis == "PS4":
        return _jugar_ps4(ruta, cfg, clave)

    # Emuladores
    cmd = cfg.get(sis) or cfg.get("Retro")
    if not cmd:
        return f"No hay emulador configurado para {sis}. Edita {CFG}"

    exe_path = cmd[0]
    real = _resolver_exe(sis, exe_path)
    if real and real != exe_path:
        # Si cayo en Ryujinx, su sintaxis es "Ryujinx.exe <rom>" (sin -g)
        cmd = [real, "{rom}"] if "ryujinx" in real.lower() else [real] + cmd[1:]
        exe_path = real
    if not os.path.exists(exe_path):
        retro = cfg.get("Retro", EMU_DEFECTO.get("Retro", [""]))[0]
        if os.path.exists(retro) and sis != "PS4":
            cmd = [retro]
            exe_path = retro
        else:
            return f"Falta el emulador de {sis}:\n{exe_path}\n\nInstalalo en esa ruta o edita {CFG}"

    rom = ruta
    if os.path.isdir(ruta):
        eboot = os.path.join(ruta, "eboot.bin")
        if os.path.exists(eboot):
            rom = eboot
        else:
            mejores = []
            for r, _, fs in os.walk(ruta):
                for f in fs:
                    if _es_rom_valida(f, sis):
                        p = os.path.join(r, f)
                        try:
                            mejores.append((p, os.path.getsize(p)))
                        except Exception:
                            pass
            if mejores:
                rom = max(mejores, key=lambda x: x[1])[0]

    args = [a.replace("{rom}", rom) for a in cmd]
    if len(cmd) == 1 and sis not in ("Retro",):
        args.append(rom)

    try:
        cwd = os.path.dirname(exe_path) or None
        proc = subprocess.Popen(args, cwd=cwd)
    except Exception as e:
        return f"Error al lanzar {sis}: {e}"
    _lanzado(proc, clave)
    return ""


def _jugar_ps4(ruta: str, cfg: dict, clave: str = None) -> str:
    """Lanza un juego de PS4 con shadPS4 (-g <eboot.bin>)."""
    cmd = list(cfg.get("PS4") or EMU_DEFECTO["PS4"])
    exe = cmd[0]
    if not os.path.exists(exe):
        return ("shadPS4 no esta instalado.\n"
                "Abri la Tienda (T) > Emuladores > shadPS4 y apreta Enter para instalarlo.")

    if ruta.lower().endswith(".pkg"):
        return ("Los .pkg de PS4 hay que instalarlos primero.\n"
                "Abri shadPS4 > Archivo > Instalar PKG, y luego apreta R para re-escanear.")

    eboot = os.path.join(ruta, "eboot.bin") if os.path.isdir(ruta) else ruta
    if not os.path.exists(eboot):
        return f"No encontre eboot.bin en:\n{ruta}"

    args = [a.replace("{rom}", eboot) for a in cmd]
    if eboot not in args:                      # config sin {rom}: agregar -g
        args += ["-g", eboot]
    if kiosk.active and "-f" not in args and "--fullscreen" not in args:
        args += ["-f", "true"]                 # modo consola: pantalla completa

    try:
        proc = subprocess.Popen(args, cwd=os.path.dirname(exe) or None)
    except Exception as e:
        return f"Error al lanzar shadPS4: {e}"
    _lanzado(proc, clave)
    return ""


def abrir_shadps4_gui(cfg: dict) -> str:
    """Abre shadPS4 sin juego (build Qt: Archivo > Instalar PKG).
    Devuelve "" si salio bien, o un mensaje de error."""
    cmd = list(cfg.get("PS4") or EMU_DEFECTO["PS4"])
    exe = cmd[0]
    if not os.path.exists(exe):
        return ("shadPS4 no esta instalado.\n"
                "Tienda (T) > Emuladores > shadPS4 > Enter para instalarlo.")
    try:
        proc = subprocess.Popen([exe], cwd=os.path.dirname(exe) or None)
    except Exception as e:
        return f"Error al abrir shadPS4: {e}"
    kiosk.game_launched(proc)
    return ""
