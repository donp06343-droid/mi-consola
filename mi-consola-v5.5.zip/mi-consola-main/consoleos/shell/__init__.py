"""
Capa 1 - Shell / Kiosk Mode.

Uso desde el launcher:

    from consoleos.shell import kiosk, EV_ESCAPE
"""
from .controller import EV_ESCAPE, KioskController, kiosk

__all__ = ["kiosk", "KioskController", "EV_ESCAPE"]
