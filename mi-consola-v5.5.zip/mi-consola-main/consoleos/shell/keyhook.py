"""
Bloqueo de atajos del sistema con un hook global de teclado (WH_KEYBOARD_LL).

Que se bloquea
--------------
    Tecla Windows (izq. y der.)  -> sin Inicio, Win+D, Win+E, Win+Tab, etc.
    Alt+Tab, Alt+Esc             -> sin cambiar de ventana
    Ctrl+Esc, Ctrl+Shift+Esc     -> sin menu Inicio ni Administrador de tareas
    Alt+F4                       -> bloqueado SOLO sobre el launcher; en juegos y
                                    emuladores sigue funcionando para poder
                                    cerrar un programa colgado (configurable).

Que NO se puede bloquear (Windows lo reserva por seguridad)
-----------------------------------------------------------
    Ctrl+Alt+Supr y Win+L. Quedan como salida de emergencia natural.

Por que un hilo propio
----------------------
Un hook de bajo nivel exige que el hilo que lo instala bombee mensajes, y que
la funcion responda en menos de ~300 ms o Windows lo desinstala en silencio.
Por eso vive en su hilo con su propio bucle de mensajes, separado del bucle de
render de pygame.
"""
from __future__ import annotations

import os
import threading
from typing import FrozenSet, Optional, Set

from consoleos.log import get_logger
from consoleos.shell import winapi
from consoleos.shell.escape import HoldTrigger

log = get_logger("keyhook")

WH_KEYBOARD_LL = 13
HC_ACTION = 0
WM_KEYDOWN, WM_KEYUP, WM_SYSKEYDOWN, WM_SYSKEYUP = 0x0100, 0x0101, 0x0104, 0x0105
WM_QUIT = 0x0012
PM_NOREMOVE = 0x0000
LLKHF_ALTDOWN = 0x20
LLKHF_INJECTED = 0x10

_MODIFIERS = frozenset({winapi.VK_SHIFT, winapi.VK_CONTROL, winapi.VK_MENU})
_NORMALIZE = {0xA0: 0x10, 0xA1: 0x10,      # L/R Shift  -> Shift
              0xA2: 0x11, 0xA3: 0x11,      # L/R Ctrl   -> Ctrl
              0xA4: 0x12, 0xA5: 0x12}      # L/R Alt    -> Alt


def _norm(vk: int) -> int:
    return _NORMALIZE.get(vk, vk)


if winapi.IS_WINDOWS:
    import ctypes
    from ctypes import wintypes

    _user32 = winapi.user32
    _HOOKPROC = ctypes.WINFUNCTYPE(winapi.LRESULT, ctypes.c_int, winapi.WPARAM, winapi.LPARAM)

    class _KBDLLHOOKSTRUCT(ctypes.Structure):
        _fields_ = [
            ("vkCode", wintypes.DWORD),
            ("scanCode", wintypes.DWORD),
            ("flags", wintypes.DWORD),
            ("time", wintypes.DWORD),
            ("dwExtraInfo", ctypes.c_size_t),
        ]

    _SetWindowsHookExW = winapi._bind(_user32, "SetWindowsHookExW", wintypes.HANDLE,
                                      ctypes.c_int, _HOOKPROC, wintypes.HINSTANCE, wintypes.DWORD)
    _UnhookWindowsHookEx = winapi._bind(_user32, "UnhookWindowsHookEx", wintypes.BOOL, wintypes.HANDLE)
    _CallNextHookEx = winapi._bind(_user32, "CallNextHookEx", winapi.LRESULT,
                                   wintypes.HANDLE, ctypes.c_int, winapi.WPARAM, winapi.LPARAM)
    _GetMessageW = winapi._bind(_user32, "GetMessageW", ctypes.c_int,
                                ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT)
    _PeekMessageW = winapi._bind(_user32, "PeekMessageW", wintypes.BOOL,
                                 ctypes.POINTER(wintypes.MSG), wintypes.HWND,
                                 wintypes.UINT, wintypes.UINT, wintypes.UINT)
    _PostThreadMessageW = winapi._bind(_user32, "PostThreadMessageW", wintypes.BOOL,
                                       wintypes.DWORD, wintypes.UINT, winapi.WPARAM, winapi.LPARAM)
    _GetModuleHandleW = winapi._bind(winapi.kernel32, "GetModuleHandleW", wintypes.HMODULE, wintypes.LPCWSTR)


class KeyboardGuard:
    """Instala el hook y aplica las reglas de bloqueo. Todo es no-op fuera de Windows."""

    def __init__(self, combo: FrozenSet[int], trigger: HoldTrigger,
                 allow_altf4_in_games: bool = True) -> None:
        self._combo = combo
        self._trigger = trigger
        self._allow_altf4_in_games = allow_altf4_in_games
        self._keys: Set[int] = set()            # teclas no modificadoras pulsadas
        self._thread: Optional[threading.Thread] = None
        self._thread_id = 0
        self._hook = None
        self._callback = None                   # referencia fuerte: si se recolecta, el hook crashea
        self._ready = threading.Event()
        self._pid = os.getpid()

    # ---------------------------------------------------------------- ciclo
    def start(self) -> bool:
        if not winapi.IS_WINDOWS or self._thread is not None:
            return False
        self._ready.clear()
        self._thread = threading.Thread(target=self._run, name="consoleos-keyhook", daemon=True)
        self._thread.start()
        installed = self._ready.wait(3.0) and self._hook is not None
        if not installed:
            log.error("No se pudo instalar el hook de teclado")
        return installed

    def stop(self) -> None:
        thread, self._thread = self._thread, None
        if thread is None:
            return
        if self._thread_id:
            _PostThreadMessageW(self._thread_id, WM_QUIT, 0, 0)
        thread.join(timeout=2.0)
        self._trigger.cancel()

    def _run(self) -> None:
        self._thread_id = winapi.current_thread_id()
        msg = wintypes.MSG()
        _PeekMessageW(ctypes.byref(msg), None, 0, 0, PM_NOREMOVE)   # fuerza la cola de mensajes
        self._callback = _HOOKPROC(self._proc)
        hook = _SetWindowsHookExW(WH_KEYBOARD_LL, self._callback, _GetModuleHandleW(None), 0)
        if not hook:
            log.error("SetWindowsHookEx fallo (error %s)", ctypes.get_last_error())
            self._hook = None
            self._ready.set()
            return
        self._hook = hook
        log.info("Hook de teclado instalado")
        self._ready.set()
        try:
            while _GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
                pass
        finally:
            _UnhookWindowsHookEx(hook)
            self._hook = None
            log.info("Hook de teclado retirado")

    # ----------------------------------------------------------------- hook
    def _proc(self, n_code, w_param, l_param):
        try:
            if n_code == HC_ACTION:
                kb = ctypes.cast(l_param, ctypes.POINTER(_KBDLLHOOKSTRUCT)).contents
                if self._handle(kb, w_param):
                    return 1                    # tecla consumida: Windows no la ve
        except Exception:                       # un fallo aqui jamas debe bloquear el teclado
            log.exception("Error en el hook de teclado")
        return _CallNextHookEx(None, n_code, w_param, l_param)

    def _handle(self, kb, w_param) -> bool:
        if kb.flags & LLKHF_INJECTED:           # eventos sinteticos (nuestro truco de foco, teclados virtuales)
            return False

        vk = _norm(kb.vkCode)
        down = w_param in (WM_KEYDOWN, WM_SYSKEYDOWN)

        if vk not in _MODIFIERS:
            if down:
                self._keys.add(vk)
            else:
                self._keys.discard(vk)
        self._trigger.update(self._combo_active(vk, down))

        alt = bool(kb.flags & LLKHF_ALTDOWN) or (vk == winapi.VK_MENU and down)
        ctrl = winapi.async_key_down(winapi.VK_CONTROL)

        if vk in (winapi.VK_LWIN, winapi.VK_RWIN):
            return True                         # down y up: si no, el Inicio abre al soltar
        if vk == winapi.VK_TAB and alt:
            return True
        if vk == winapi.VK_ESCAPE and (alt or ctrl):
            return True
        if vk == winapi.VK_F4 and alt:
            return self._block_alt_f4()
        return False

    def _combo_active(self, ev_vk: int, ev_down: bool) -> bool:
        """
        Combinacion secreta pulsada. El hook corre ANTES de que Windows actualice
        su estado, asi que la tecla del evento actual se toma del propio evento y
        los modificadores restantes se resincronizan con el estado fisico.
        """
        for req in self._combo:
            if req == ev_vk:
                ok = ev_down
            elif req in _MODIFIERS:
                ok = winapi.async_key_down(req)
            else:
                ok = req in self._keys
            if not ok:
                return False
        return True

    def combo_still_held(self) -> bool:
        """Verificacion final antes de disparar: todas las teclas siguen fisicamente pulsadas."""
        return all(winapi.async_key_down(vk) for vk in self._combo)

    def _block_alt_f4(self) -> bool:
        if not self._allow_altf4_in_games:
            return True
        # Solo protegemos al launcher; en cualquier otro programa Alt+F4 pasa.
        return winapi.window_pid(winapi.get_foreground_window()) == self._pid
