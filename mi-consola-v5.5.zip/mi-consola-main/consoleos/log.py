"""
Logging de Mi Consola OS.

Escribe en <BASE>\\logs\\consoleos.log (rotativo, max ~2 MB en total).
Si esa ruta no es escribible (por ejemplo D:\\ no existe) usa la carpeta TEMP.
Nunca lanza excepciones: un fallo de log no debe tumbar la consola.
"""
from __future__ import annotations

import logging
import os
import tempfile
from logging.handlers import RotatingFileHandler

_ROOT_NAME = "consoleos"
_configured = False


def _candidate_dirs():
    try:
        from config import BASE
        yield os.path.join(BASE, "logs")
    except Exception:
        pass
    yield os.path.join(tempfile.gettempdir(), "mi_consola_logs")


def _configure() -> None:
    global _configured
    if _configured:
        return
    _configured = True
    root = logging.getLogger(_ROOT_NAME)
    root.setLevel(logging.INFO)
    root.propagate = False
    for d in _candidate_dirs():
        try:
            os.makedirs(d, exist_ok=True)
            handler = RotatingFileHandler(
                os.path.join(d, "consoleos.log"),
                maxBytes=512 * 1024, backupCount=3, encoding="utf-8",
            )
            handler.setFormatter(logging.Formatter(
                "%(asctime)s %(levelname)-7s %(name)s: %(message)s"))
            root.addHandler(handler)
            return
        except OSError:
            continue
    root.addHandler(logging.NullHandler())


def get_logger(name: str = "") -> logging.Logger:
    _configure()
    return logging.getLogger(f"{_ROOT_NAME}.{name}" if name else _ROOT_NAME)
