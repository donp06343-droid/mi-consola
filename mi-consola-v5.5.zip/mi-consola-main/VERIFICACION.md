# Verificacion (v5.2)

Leyenda: VERIFICADO = comprobado contra una fuente; NO VERIFICADO = hay que probarlo en una PC real.

## shadPS4 (verificado por Claude, 2026-11-22)
- Ultima estable: v0.21.0 (30-oct-2026), repo `shadps4-emu/shadPS4` - VERIFICADO
  (https://shadps4.net, https://sourceforge.net/projects/shadps4.mirror/files/)
- Asset Windows: `shadps4-win64-sdl-0.21.0.zip` (solo build SDL) - VERIFICADO (espejo SourceForge)
- Flags `-g` y `-f true` - segun README oficial (reportado por Grok) - NO VERIFICADO por Claude
- Que el build SDL abra una GUI sin argumentos (tecla G) - NO VERIFICADO

## Emuladores (investigado por Grok en la rama grok-tarea-2; patrones NO re-verificados por Claude)
| Emulador | Repo | Patron de asset | Estado |
|---|---|---|---|
| PPSSPP | hrydgard/ppsspp | `PPSSPP-*-Windows-x64.zip` | NO VERIFICADO |
| DuckStation | stenzek/duckstation | `duckstation-windows-x64-release.zip` | NO VERIFICADO |
| PCSX2 | PCSX2/pcsx2 | `pcsx2-*-windows-x64-Qt.7z` | NO VERIFICADO |
| RPCS3 | RPCS3/rpcs3-binaries-win | `rpcs3-*_win64_msvc.7z` | NO VERIFICADO |
| mGBA | mgba-emu/mgba | `mGBA-*-win64.7z` | NO VERIFICADO |
| melonDS | melonDS-emu/melonDS | `melonDS-*-windows-x86_64.zip` | NO VERIFICADO |
| Cemu | cemu-project/Cemu | `cemu-*-windows-x64.zip` | NO VERIFICADO |
| Azahar (3DS) | azahar-emu/azahar | `azahar-windows-msvc-*.zip` | NO VERIFICADO |
| Dolphin | (sin assets en GitHub) | pagina oficial | por diseno |
| Eden (Switch) | (hosts inestables) | pagina oficial | por diseno |

Si un patron no encuentra asset, la tienda abre la pagina oficial de descarga (no falla).

## Ejecutables
Nombres esperados en `EMU_DEFECTO` - NO VERIFICADOS. El launcher los busca solo:
si el configurado no existe prueba alternativas (`EMU_ALTERNATIVAS`) y luego cualquier
`.exe` parecido dentro de la carpeta del emulador.
Sin verificar: flag `-g` de Eden, nombre `azahar.exe`.

## Extraccion
- `.zip`: stdlib, aplanado y a prueba de rutas fuera del destino - probado con archivos de prueba
- `.7z`: `py7zr` o `7z.exe` (PATH, `BASE\tools\` o Program Files) - extraccion real NO probada

## Tiendas conectadas (stores.py, v5.4) - verificado por Claude, 2026-11-22
- **Epic**: manifests en `ProgramData\Epic\EpicGamesLauncher\Data\Manifests\*.item` con `AppName`,
  `DisplayName`, `InstallLocation`, `LaunchExecutable`, `bIsIncompleteInstall` - VERIFICADO
  (https://dev.epicgames.com/documentation/unreal-engine/academic-installation-of-unreal-engine, crate game-scanner)
- **Epic lanzar**: `com.epicgames.launcher://apps/<AppName>?action=launch&silent=true` - VERIFICADO (documento oficial de Epic,
  "Epic Games Protocol Activation"); tienda: `com.epicgames.launcher://store/product/<slug>` - VERIFICADO.
  `com.epicgames.launcher://store` (portada de la tienda) - NO VERIFICADO.
- **GOG**: registro `HKLM\SOFTWARE\GOG.com\Games\<id>` con `gameName`, `path`, `exe` - VERIFICADO
  (https://github.com/erri120/GameFinder/wiki/GOG-Galaxy). Se lanza el exe directo (GOG es DRM-free).
  `goggalaxy://` para abrir la tienda - NO VERIFICADO.
- **Steam**: `appmanifest_*.acf` + `libraryfolders.vdf` + `HKCU\Software\Valve\Steam\SteamPath` - VERIFICADO
  (GameFinder). `StateFlags & 4` = instalado por completo - de memoria (EAppState), NO VERIFICADO contra fuente.
  `steam://rungameid/<id>` y `steam://store/<id>` - de uso comun, NO VERIFICADO contra documentacion oficial.
- **Xbox / Microsoft Store**: `ms-windows-store://home` - NO VERIFICADO. Deteccion de juegos instalados: NO IMPLEMENTADA.
- **EA App, Ubisoft Connect, Battle.net, itch.io**: NO IMPLEMENTADOS.
- Probado con manifests/registro simulados (Linux). NO probado en Windows con tiendas reales.

## Portadas y estadisticas (v5.5) - verificado por Claude, 2026-11-22
- **Tiempo jugado en Steam**: `userdata\<id>\config\localconfig.vdf` -> `...\Steam\apps\<appid>` con `Playtime`
  (minutos) y `Playtime2wks` - VERIFICADO (https://github.com/divadsn/steam_account_changer/blob/master/changer.py).
- **Campos del appmanifest**: `SizeOnDisk`, `LastUpdated`, `StateFlags`, `installdir` - VERIFICADO (crate game-detector).
  `LastPlayed` NO aparece en esas fuentes: no se usa.
- **Portadas Steam**: `https://cdn.akamai.steamstatic.com/steam/apps/<appid>/library_600x900.jpg` - VERIFICADO
  (SteamViewer README; hay respaldo al CDN viejo y a header.jpg).
- **Buscador de la tienda de Steam** `store.steampowered.com/api/storesearch/?term=` (nombre -> appid, usado para Epic/GOG):
  nombre del endpoint VERIFICADO (listado de endpoints publicos), formato exacto de la respuesta (`items[].id/name/type`)
  de memoria - NO VERIFICADO contra una respuesta real. Es un endpoint sin documentar, puede cambiar.
- **SteamGridDB** (`/search/autocomplete/<term>`, `/grids/game/<id>`): base URL y auth Bearer VERIFICADOS;
  rutas exactas de los endpoints de memoria - NO VERIFICADO. Es opcional (requiere clave en `claves.json`).
- **Epic**: no guarda tiempo jugado en archivos locales (que se sepa) -> solo inicios y ultima vez. NO VERIFICADO que sea imposible.
- Probado con servidor/archivos simulados (Linux). NO probado con tu Steam/Epic/GOG reales ni la pantalla con pygame.
