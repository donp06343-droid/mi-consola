# Prompt para Grok — Mi Consola (repo: mi-consola)

Actua como ingeniero senior de Python/Windows. Trabajas sobre **Mi Consola**, un
frontend tipo consola (pygame) para Windows con modo kiosk, tienda de juegos
gratis/legales, descargas y lanzador de emuladores. Repo: `mi-consola` (rama main).
Idioma de UI, comentarios y commits: **español rioplatense simple**.

## Vision del proyecto (importante)
Este repo lo construimos entre IAs. La meta a largo plazo es:
1. **Consola/sistema operativo para PC** (Consola OS): la PC arranca directo en Mi Consola,
   sin escritorio (kiosk -> shell reemplazado -> imagen de sistema propia).
2. **Consola fisica** propia basada en este software.
Toda decision tecnica debe acercarse a eso: arranque sin escritorio, control total con mando,
actualizaciones automaticas, estabilidad y recuperacion ante fallos. Ver ROADMAP.md.

## Contexto tecnico (leelo antes de tocar nada)
- Entrada: `main.py` (bucle pygame, vistas: inicio / descargas / tienda / controles).
- `config.py`: rutas (BASE por defecto `D:\Emulacion`, env `MI_CONSOLA_BASE`),
  `EMU_DEFECTO` (comando por sistema), `EXT_ROM`.
- `library.py` escanea ROMs, PC (Steam/Epic/generico) y favoritos.
- `launcher.py` lanza juegos; PS4 tiene flujo propio (`_jugar_ps4`).
- `ps4.py`: parser de `param.sfo`, deteccion de juegos con `eboot.bin`, icono `icon0.png`.
- `store.py`: `TIENDA` (lista de dicts creados con `_j(...)`), `CATEGORIAS`, `filtrar()`,
  `resolver()` (GitHub releases, acepta `pats=[...]` por prioridad), `pedir()`.
- `downloads.py`: cola con reanudacion; `agregar_enlaces(..., destino=...)` extrae el zip
  aplanado y a prueba de rutas fuera del destino.
- `consoleos/`: kiosk (oculta barra de tareas, bloquea atajos, foco, PIN). **No romper.**

## Ya hecho en v5.1 (no lo repitas)
1. shadPS4: instalacion desde la tienda, deteccion por `eboot.bin`, nombre/portada desde
   `sce_sys`, lanzamiento `-g <eboot.bin>` (+ `-f true` en modo consola), aviso para `.pkg`.
2. Tienda: 51 titulos con categorias y filtro con izquierda/derecha.
3. Descargas con carpeta destino fija + extraccion segura.
3b. v5.2: instalador de emuladores (PPSSPP, DuckStation, PCSX2, RPCS3, mGBA, melonDS, Cemu,
   Azahar), `.7z`, `EMU_ALTERNATIVAS` y deteccion automatica del .exe. Ver VERIFICACION.md.
4. Tarea 1 (parcial, hecha por Grok + integrada): tecla G abre la GUI de shadPS4
   (`abrir_shadps4_gui` en launcher.py). **Falta** verificar assets/flags contra el release real.

## Reglas obligatorias
- **Antes de empezar: hace `pull` de main y confirma que `config.VERSION` es >= 5.2.**
  Cada tarea parte de la rama `main` actual. NUNCA borres juegos u otras features existentes
  del catalogo de `store.py` (en la tarea 2 se borraron 3 por trabajar sobre una base vieja).
- **Solo software legal**: open source, freeware, free-to-play oficial, emuladores.
  PROHIBIDO agregar links a ROMs/ISOs/juegos pirata, firmware, claves o BIOS.
- No tocar la logica del kiosk (`consoleos/`) salvo bug demostrable.
- No inventar nombres de assets de GitHub ni flags de CLI: **verificalos** (release real,
  `--help` del emulador). Si no podes verificar algo, dejalo marcado con `# TODO verificar`.
- Cambios chicos, un commit por tarea, mensaje claro. Mantene compatibilidad con Python 3.12+.
- Todo falla con gracia: sin internet, sin emulador, sin permisos → mensaje en pantalla, nunca traceback.

## Tareas (en este orden)
1. **Verificar shadPS4**: confirmar contra el release actual los nombres de asset
   (`win64-qt` / `win64-sdl`) y los flags `-g` y `-f`; corregir `store.py` / `launcher.py`
   si cambiaron. Agregar en la vista de inicio una accion para abrir la GUI de shadPS4
   (instalar PKG) sin juego.
2. ~~**Instalador generico de emuladores**~~ (HECHO en v5.2; resta verificar en una PC real) **Instalador generico de emuladores**: categoria *Emuladores* con PPSSPP, Dolphin,
   DuckStation, PCSX2, RPCS3, mGBA, melonDS, Cemu y el emulador de Switch/3DS que siga
   mantenido hoy (verificar: Ryujinx y Citra fueron discontinuados; buscar sucesores
   activos y actualizar `EMU_DEFECTO`). Soportar `.7z` (py7zr o `7z.exe`) en `downloads.py`.
   Ruta final debe coincidir con `EMU_DEFECTO`.
3. **Diagnostico de emuladores**: pantalla "Estado del sistema" que liste cada emulador
   (instalado / falta / ruta) y permita instalarlo con Enter.
4. **Tests y CI**: `pytest` para `ps4.py` (SFO), `downloads._extraer_plano`, `store.resolver`
   (con respuestas mockeadas) y `library.escanear` sobre un arbol falso; workflow de
   GitHub Actions que corra los tests en Windows y Linux (pygame mockeado o `SDL_VIDEODRIVER=dummy`).
5. **UX con mando**: navegacion completa de la tienda con gamepad, teclado en pantalla
   para la busqueda, y mostrar progreso de descarga (%, MB/s) en la vista de descargas.
6. **Metadatos**: tiempo jugado y "ultimo jugado" por juego, fila "Continuar jugando"
   en inicio, guardado en JSON junto a favoritos.
7. **Empaquetado**: script PyInstaller (`build_exe.bat`) que genere `MiConsola.exe`
   y actualizar `instalar_en_D.bat`.

## Entrega
Por cada tarea: lista de archivos modificados, como probarlo, y cualquier cosa que no
hayas podido verificar. Termina con un resumen y un CHANGELOG actualizado.
