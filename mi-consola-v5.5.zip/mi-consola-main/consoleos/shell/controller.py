"""
KioskController: unica puerta de entrada de la Capa 1.

El resto del launcher solo usa la instancia `kiosk` de este modulo:

    kiosk.prepare(modo)          antes de pygame.init()
    kiosk.start()                despues de crear la ventana
    kiosk.handle_event(e)        primera linea del bucle de eventos
    kiosk.game_launched(proc)    al lanzar un juego/emulador
    kiosk.stop()                 al salir (idempotente, tambien via atexit)

En modo NORMAL todos los metodos son no-op, asi que el launcher no necesita
ramificar su logica segun el modo.
"""
from __future__ import annotations

import atexit
import os
import subprocess
import tempfile
import threading
from typing import Optional

import pygame

from consoleos.log import get_logger
from consoleos.modes import Mode
from consoleos.settings import Settings
from consoleos.shell import winapi
from consoleos.shell.escape import HoldTrigger, PadCombo, parse_combo
from consoleos.shell.focus import FocusManager
from consoleos.shell.keyhook import KeyboardGuard
from consoleos.shell.taskbar import TaskbarController

log = get_logger("kiosk")

# Evento publicado por la combinacion secreta (teclado o mando).
EV_ESCAPE = pygame.event.custom_type()

_MUTEX_NAME = "Local\\MiConsola.Kiosk"
_LOCK_PATH = os.path.join(tempfile.gettempdir(), "mi_consola_kiosk.lock")

_INPUT_EVENTS = frozenset({
    pygame.KEYDOWN, pygame.KEYUP, pygame.TEXTINPUT,
    pygame.JOYBUTTONDOWN, pygame.JOYBUTTONUP, pygame.JOYHATMOTION, pygame.JOYAXISMOTION,
    pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION,
})
_PAD_EVENTS = frozenset({pygame.JOYBUTTONDOWN, pygame.JOYBUTTONUP, pygame.JOYDEVICEREMOVED})

_DEFAULT_ESCAPE_KEYS = ["ctrl", "shift", "f12"]


class KioskController:
    def __init__(self) -> None:
        self.mode: Mode = Mode.NORMAL
        self.settings: Optional[Settings] = None
        self.active = False
        self.overlay_open = False
        self.hwnd = 0

        self._taskbar = TaskbarController()
        self._guard: Optional[KeyboardGuard] = None
        self._focus: Optional[FocusManager] = None
        self._pad: Optional[PadCombo] = None
        self._kb_trigger: Optional[HoldTrigger] = None
        self._pad_trigger: Optional[HoldTrigger] = None
        self._mutex: Optional[int] = None
        self._return_hwnd = 0
        self._stop_lock = threading.Lock()

    # ------------------------------------------------------------ arranque
    def prepare(self, requested: Optional[Mode] = None) -> bool:
        """
        Carga la configuracion y decide el modo. Llamar ANTES de pygame.init().
        Devuelve False si no se debe continuar (ya hay otra consola corriendo).
        """
        self.settings = Settings.load()
        self.mode = requested or Mode.parse(self.settings.mode, Mode.NORMAL)
        self.recover_stale_state()

        if self.mode is not Mode.CONSOLE:
            return True
        if not winapi.IS_WINDOWS:
            print("[consoleos] El modo consola solo existe en Windows; se usa el modo normal.")
            log.warning("Modo consola pedido fuera de Windows: se ignora")
            self.mode = Mode.NORMAL
            return True

        handle, already = winapi.try_acquire_mutex(_MUTEX_NAME)
        if already:
            winapi.release_handle(handle)
            log.warning("Ya hay una instancia en modo consola; se cancela el arranque")
            return False
        self._mutex = handle

        # SDL: seguir leyendo el mando con un juego en primer plano (para la
        # combinacion secreta) y no cerrar la ventana con Alt+F4.
        os.environ.setdefault("SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS", "1")
        os.environ.setdefault("SDL_WINDOWS_NO_CLOSE_ON_ALT_F4", "1")
        return True

    def start(self) -> bool:
        """Activa el kiosk. Llamar despues de pygame.display.set_mode()."""
        if self.mode is not Mode.CONSOLE or self.active or self.settings is None:
            return False
        s = self.settings
        try:
            self.hwnd = int(pygame.display.get_wm_info().get("window", 0))
        except (pygame.error, TypeError, ValueError):
            self.hwnd = 0
        log.info("Iniciando modo consola (hwnd=%s)", self.hwnd)

        self._write_lock()

        if s.hide_taskbar:
            self._taskbar.hide()
            self._taskbar.start_guard()
        if s.force_topmost and self.hwnd:
            winapi.set_topmost(self.hwnd, True)
            winapi.force_foreground(self.hwnd)

        self._focus = FocusManager(self.hwnd, manage_topmost=s.force_topmost)
        self._focus.start()

        # Combinacion secreta: teclado (dentro del hook) y mando.
        self._pad_trigger = HoldTrigger(
            s.escape_hold_seconds, self._post_escape,
            verify=lambda: self._pad is not None and self._pad.is_active())
        self._pad = PadCombo(s.escape_pad_buttons, self._pad_trigger)

        if s.block_keys:
            try:
                combo = parse_combo(s.escape_keys)
            except ValueError as e:
                log.warning("escape_keys invalido (%s); uso %s", e, _DEFAULT_ESCAPE_KEYS)
                combo = parse_combo(_DEFAULT_ESCAPE_KEYS)
            self._kb_trigger = HoldTrigger(
                s.escape_hold_seconds, self._post_escape,
                verify=lambda: self._guard is not None and self._guard.combo_still_held())
            self._guard = KeyboardGuard(combo, self._kb_trigger, s.allow_altf4_in_games)
            if not self._guard.start():
                self._guard = None

        self._install_signal_handlers()
        atexit.register(self.stop)
        self.active = True
        return True

    def stop(self) -> None:
        """Deshace todo. Idempotente; seguro de llamar desde atexit o tras un fallo."""
        with self._stop_lock:
            if not self.active and self._mutex is None:
                return
            self.active = False
            log.info("Deteniendo modo consola")
            steps = (
                ("hook de teclado", lambda: self._guard and self._guard.stop()),
                ("vigilante de foco", lambda: self._focus and self._focus.stop()),
                ("combo teclado", lambda: self._kb_trigger and self._kb_trigger.cancel()),
                ("combo mando", lambda: self._pad_trigger and self._pad_trigger.cancel()),
                ("barra de tareas", self._taskbar.restore),
                ("ventana", lambda: winapi.set_topmost(self.hwnd, False)),
                ("lock", self._remove_lock),
                ("mutex", self._release_mutex),
            )
            for name, step in steps:
                try:
                    step()
                except Exception:
                    log.exception("Error al detener: %s", name)
            self._guard = self._focus = self._pad = None

    # ------------------------------------------------------------- eventos
    def handle_event(self, event) -> bool:
        """
        True = el evento queda consumido y el launcher no debe procesarlo.
        EV_ESCAPE nunca se consume: lo atiende main.py abriendo el menu con PIN.
        """
        if not self.active:
            return False
        t = event.type

        if t == EV_ESCAPE:
            self._remember_foreign_window()
            winapi.force_foreground(self.hwnd)
            return False

        if self._pad is not None and t in _PAD_EVENTS:
            self._pad.feed(event)

        if t == pygame.QUIT:
            return True                       # en modo consola la ventana no se cierra con eventos del sistema
        if t in _INPUT_EVENTS and self.input_locked():
            return True
        return False

    def input_locked(self) -> bool:
        """
        Con un juego en primer plano, el mando sigue llegando al launcher (por
        el modo "background events"). Se descarta para que pulsar A en el juego
        no mueva el menu de atras. Si el foco es del launcher nunca se bloquea,
        salvo la breve guardia posterior a lanzar (evita doble lanzamiento).
        """
        if not self.active or self.overlay_open or self._focus is None:
            return False
        if not self._focus.game_running:
            return False
        if self._focus.in_launch_guard():
            return True
        return winapi.get_foreground_window() != self.hwnd

    # -------------------------------------------------------- juegos y foco
    def game_launched(self, proc=None) -> None:
        if not self.active or self._focus is None:
            return
        pid = getattr(proc, "pid", None)
        if pid:
            self._focus.track_process(pid)
        else:
            self._focus.track_external()

    def external_launched(self, grace: float = 60.0) -> None:
        if self.active and self._focus is not None:
            self._focus.track_external(grace)

    @property
    def game_running(self) -> bool:
        return bool(self._focus and self._focus.game_running)

    def bring_to_front(self) -> bool:
        return bool(self.active and self._focus and self._focus.bring_to_front())

    def set_overlay(self, is_open: bool) -> None:
        """El menu del sistema avisa cuando se abre/cierra."""
        self.overlay_open = is_open
        if self._focus is not None:
            self._focus.overlay_open = is_open
        if not is_open:
            self._restore_game_focus()

    # ------------------------------------------------------ acciones sistema
    def exit_to_desktop(self) -> bool:
        if self.settings is None or not self.settings.allow_exit_to_desktop:
            return False
        log.info("Salida al escritorio de Windows")
        self.stop()
        self._ensure_windows_shell()
        return True

    def power(self, action: str) -> bool:
        """action: 'restart' | 'shutdown'."""
        flag = {"restart": "/r", "shutdown": "/s"}.get(action)
        if flag is None or not winapi.IS_WINDOWS:
            return False
        try:
            subprocess.Popen(["shutdown", flag, "/t", "0"], creationflags=winapi.CREATE_NO_WINDOW)
        except OSError:
            log.exception("No se pudo ejecutar shutdown")
            return False
        log.info("Accion de energia: %s", action)
        return True

    # ---------------------------------------------------------- recuperacion
    def recover_stale_state(self) -> None:
        """
        Si una ejecucion anterior murio sin limpiar (crash, kill), la barra de
        tareas puede haber quedado oculta. Se detecta por el archivo lock y por
        no haber ninguna consola viva (el mutex esta libre).
        """
        if not winapi.IS_WINDOWS or not os.path.exists(_LOCK_PATH):
            return
        handle, already = winapi.try_acquire_mutex(_MUTEX_NAME)
        winapi.release_handle(handle)
        if already:
            return                                   # hay otra consola viva: su estado es legitimo
        log.warning("Estado previo sin limpiar: restaurando barra de tareas")
        TaskbarController.restore_all()
        self._remove_lock()

    # -------------------------------------------------------------- internos
    def _post_escape(self) -> None:
        try:
            pygame.event.post(pygame.event.Event(EV_ESCAPE))
        except pygame.error:
            log.warning("No se pudo publicar EV_ESCAPE (pygame cerrado)")

    def _remember_foreign_window(self) -> None:
        fg = winapi.get_foreground_window()
        if fg and fg != self.hwnd and winapi.window_pid(fg) != os.getpid():
            self._return_hwnd = fg

    def _restore_game_focus(self) -> None:
        """Si se cancela el menu con un juego en curso, devolver el foco al juego."""
        hwnd, self._return_hwnd = self._return_hwnd, 0
        if hwnd and self.game_running and winapi.is_window(hwnd):
            winapi.force_foreground(hwnd)

    def _ensure_windows_shell(self) -> None:
        """Si Windows arranco sin explorer.exe (shell reemplazado), lo inicia para tener escritorio."""
        if not winapi.IS_WINDOWS or winapi.find_window("Shell_TrayWnd"):
            return
        try:
            subprocess.Popen(["explorer.exe"], creationflags=winapi.CREATE_NO_WINDOW)
            log.info("explorer.exe iniciado (no habia shell)")
        except OSError:
            log.exception("No se pudo iniciar explorer.exe")

    def _write_lock(self) -> None:
        try:
            with open(_LOCK_PATH, "w", encoding="utf-8") as f:
                f.write(str(os.getpid()))
        except OSError:
            log.warning("No se pudo escribir el archivo lock")

    @staticmethod
    def _remove_lock() -> None:
        try:
            os.remove(_LOCK_PATH)
        except OSError:
            pass

    def _release_mutex(self) -> None:
        winapi.release_handle(self._mutex)
        self._mutex = None

    def _install_signal_handlers(self) -> None:
        import signal
        if threading.current_thread() is not threading.main_thread():
            return

        def _handler(_signum, _frame):
            self.stop()
            raise SystemExit(0)

        for name in ("SIGINT", "SIGTERM", "SIGBREAK"):
            sig = getattr(signal, name, None)
            if sig is None:
                continue
            try:
                signal.signal(sig, _handler)
            except (ValueError, OSError):
                pass


kiosk = KioskController()
