@echo off
REM Mi Consola - Iniciar en MODO NORMAL (ventana de pygame, sin tocar Windows)
cd /d "%~dp0.."
python main.py --mode normal
