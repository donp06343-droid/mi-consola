"""
Acceso minimo y tipado a la API de Windows mediante ctypes.

Decisiones de diseno
--------------------
* Solo ctypes (sin pywin32): el proyecto mantiene una unica dependencia.
* Todas las funciones publicas son seguras en cualquier sistema operativo:
  fuera de Windows devuelven un valor neutro (0, False, [], {}) para que el
  launcher pueda desarrollarse y ejecutarse tambien en Linux/macOS.
* Se declaran argtypes/restype en cada funcion. Sin eso, ctypes trata los
  HWND/HANDLE como int de 32 bits y se corrompen en Python de 64 bits.
"""
from __future__ import annotations

import sys
from typing import Dict, List, Optional, Tuple

IS_WINDOWS = sys.platform == "win32"

# ---- constantes de ventana
SW_HIDE = 0
SW_SHOW = 5
SW_RESTORE = 9

SWP_NOSIZE = 0x0001
SWP_NOMOVE = 0x0002
SWP_NOACTIVATE = 0x0010

# ---- teclas virtuales
VK_TAB = 0x09
VK_SHIFT = 0x10
VK_CONTROL = 0x11
VK_MENU = 0x12          # Alt
VK_ESCAPE = 0x1B
VK_F4 = 0x73
VK_LWIN = 0x5B
VK_RWIN = 0x5C
KEYEVENTF_KEYUP = 0x0002

# ---- otros
ERROR_ACCESS_DENIED = 5
ERROR_ALREADY_EXISTS = 183
STILL_ACTIVE = 259
PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
TH32CS_SNAPPROCESS = 0x2
CREATE_NO_WINDOW = 0x08000000

if IS_WINDOWS:
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.WinDLL("user32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    WPARAM = ctypes.c_size_t
    LPARAM = ctypes.c_ssize_t
    LRESULT = ctypes.c_ssize_t
    HWND = wintypes.HWND
    HANDLE = wintypes.HANDLE
    _INVALID_HANDLE = ctypes.c_void_p(-1).value

    def _bind(lib, name, restype, *argtypes):
        fn = getattr(lib, name)
        fn.restype = restype
        fn.argtypes = list(argtypes)
        return fn

    _EnumProc = ctypes.WINFUNCTYPE(wintypes.BOOL, HWND, LPARAM)

    _FindWindowW = _bind(user32, "FindWindowW", HWND, wintypes.LPCWSTR, wintypes.LPCWSTR)
    _ShowWindow = _bind(user32, "ShowWindow", wintypes.BOOL, HWND, ctypes.c_int)
    _SetWindowPos = _bind(user32, "SetWindowPos", wintypes.BOOL, HWND, HWND,
                          ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT)
    _IsWindow = _bind(user32, "IsWindow", wintypes.BOOL, HWND)
    _IsWindowVisible = _bind(user32, "IsWindowVisible", wintypes.BOOL, HWND)
    _IsIconic = _bind(user32, "IsIconic", wintypes.BOOL, HWND)
    _GetForegroundWindow = _bind(user32, "GetForegroundWindow", HWND)
    _SetForegroundWindow = _bind(user32, "SetForegroundWindow", wintypes.BOOL, HWND)
    _BringWindowToTop = _bind(user32, "BringWindowToTop", wintypes.BOOL, HWND)
    _GetWindowThreadProcessId = _bind(user32, "GetWindowThreadProcessId", wintypes.DWORD,
                                      HWND, ctypes.POINTER(wintypes.DWORD))
    _AttachThreadInput = _bind(user32, "AttachThreadInput", wintypes.BOOL,
                               wintypes.DWORD, wintypes.DWORD, wintypes.BOOL)
    _GetClassNameW = _bind(user32, "GetClassNameW", ctypes.c_int, HWND, wintypes.LPWSTR, ctypes.c_int)
    _EnumWindows = _bind(user32, "EnumWindows", wintypes.BOOL, _EnumProc, LPARAM)
    _keybd_event = _bind(user32, "keybd_event", None,
                         wintypes.BYTE, wintypes.BYTE, wintypes.DWORD, ctypes.c_size_t)
    _GetAsyncKeyState = _bind(user32, "GetAsyncKeyState", ctypes.c_short, ctypes.c_int)

    _GetCurrentThreadId = _bind(kernel32, "GetCurrentThreadId", wintypes.DWORD)
    _CloseHandle = _bind(kernel32, "CloseHandle", wintypes.BOOL, HANDLE)
    _OpenProcess = _bind(kernel32, "OpenProcess", HANDLE, wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
    _GetExitCodeProcess = _bind(kernel32, "GetExitCodeProcess", wintypes.BOOL,
                                HANDLE, ctypes.POINTER(wintypes.DWORD))
    _CreateMutexW = _bind(kernel32, "CreateMutexW", HANDLE,
                          ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR)
    _CreateToolhelp32Snapshot = _bind(kernel32, "CreateToolhelp32Snapshot", HANDLE,
                                      wintypes.DWORD, wintypes.DWORD)

    class _PROCESSENTRY32W(ctypes.Structure):
        _fields_ = [
            ("dwSize", wintypes.DWORD),
            ("cntUsage", wintypes.DWORD),
            ("th32ProcessID", wintypes.DWORD),
            ("th32DefaultHeapID", ctypes.c_size_t),
            ("th32ModuleID", wintypes.DWORD),
            ("cntThreads", wintypes.DWORD),
            ("th32ParentProcessID", wintypes.DWORD),
            ("pcPriClassBase", ctypes.c_long),
            ("dwFlags", wintypes.DWORD),
            ("szExeFile", wintypes.WCHAR * 260),
        ]

    _Process32FirstW = _bind(kernel32, "Process32FirstW", wintypes.BOOL,
                             HANDLE, ctypes.POINTER(_PROCESSENTRY32W))
    _Process32NextW = _bind(kernel32, "Process32NextW", wintypes.BOOL,
                            HANDLE, ctypes.POINTER(_PROCESSENTRY32W))


# --------------------------------------------------------------------------
# Ventanas
# --------------------------------------------------------------------------
def find_window(class_name: Optional[str] = None, title: Optional[str] = None) -> int:
    if not IS_WINDOWS:
        return 0
    return int(_FindWindowW(class_name, title) or 0)


def find_windows_by_class(class_name: str) -> List[int]:
    """Todas las ventanas de primer nivel con esa clase (p. ej. una barra por monitor)."""
    if not IS_WINDOWS:
        return []
    found: List[int] = []
    buf = ctypes.create_unicode_buffer(256)

    def _cb(hwnd, _lparam):
        if _GetClassNameW(hwnd, buf, 256) and buf.value == class_name:
            found.append(int(hwnd))
        return True

    _EnumWindows(_EnumProc(_cb), 0)
    return found


def window_class(hwnd: int) -> str:
    if not IS_WINDOWS or not hwnd:
        return ""
    buf = ctypes.create_unicode_buffer(256)
    _GetClassNameW(hwnd, buf, 256)
    return buf.value


def window_pid(hwnd: int) -> int:
    if not IS_WINDOWS or not hwnd:
        return 0
    pid = wintypes.DWORD(0)
    _GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    return int(pid.value)


def is_window(hwnd: int) -> bool:
    return bool(IS_WINDOWS and hwnd and _IsWindow(hwnd))


def is_window_visible(hwnd: int) -> bool:
    return bool(IS_WINDOWS and hwnd and _IsWindowVisible(hwnd))


def show_window(hwnd: int, cmd: int) -> bool:
    return bool(IS_WINDOWS and hwnd and _ShowWindow(hwnd, cmd))


def set_topmost(hwnd: int, on: bool) -> bool:
    """Activa/desactiva 'siempre encima' sin mover, redimensionar ni activar la ventana."""
    if not IS_WINDOWS or not hwnd:
        return False
    after = wintypes.HWND(-1 if on else -2)  # HWND_TOPMOST / HWND_NOTOPMOST
    return bool(_SetWindowPos(hwnd, after, 0, 0, 0, 0,
                              SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE))


def get_foreground_window() -> int:
    if not IS_WINDOWS:
        return 0
    return int(_GetForegroundWindow() or 0)


def current_thread_id() -> int:
    return int(_GetCurrentThreadId()) if IS_WINDOWS else 0


def force_foreground(hwnd: int) -> bool:
    """
    Trae una ventana al primer plano aunque Windows normalmente lo impida.

    Windows solo deja que cambie el foco el proceso que recibio la ultima
    entrada del usuario. Cuando un emulador termina, el foco no es nuestro, asi
    que se adjunta temporalmente la cola de entrada de este hilo a la del hilo
    en primer plano. Si aun asi falla, se usa el truco clasico de simular una
    pulsacion de Alt.
    """
    if not IS_WINDOWS or not hwnd or not _IsWindow(hwnd):
        return False
    if _IsIconic(hwnd):
        _ShowWindow(hwnd, SW_RESTORE)
    fg = int(_GetForegroundWindow() or 0)
    if fg == hwnd:
        return True

    cur_tid = int(_GetCurrentThreadId())
    fg_tid = int(_GetWindowThreadProcessId(fg, None)) if fg else 0
    attached = False
    if fg_tid and fg_tid != cur_tid:
        attached = bool(_AttachThreadInput(cur_tid, fg_tid, True))
    try:
        _BringWindowToTop(hwnd)
        ok = bool(_SetForegroundWindow(hwnd))
    finally:
        if attached:
            _AttachThreadInput(cur_tid, fg_tid, False)

    if not ok or int(_GetForegroundWindow() or 0) != hwnd:
        _keybd_event(VK_MENU, 0, 0, 0)
        _keybd_event(VK_MENU, 0, KEYEVENTF_KEYUP, 0)
        ok = bool(_SetForegroundWindow(hwnd))
    return ok


# --------------------------------------------------------------------------
# Teclado
# --------------------------------------------------------------------------
def async_key_down(vk: int) -> bool:
    """Estado fisico actual de una tecla (sirve para resincronizar modificadores)."""
    return bool(IS_WINDOWS and (_GetAsyncKeyState(vk) & 0x8000))


# --------------------------------------------------------------------------
# Procesos
# --------------------------------------------------------------------------
def process_tree() -> Dict[int, int]:
    """{pid: pid_padre} de todos los procesos vivos."""
    if not IS_WINDOWS:
        return {}
    snap = _CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    if snap is None or snap == _INVALID_HANDLE:
        return {}
    result: Dict[int, int] = {}
    try:
        entry = _PROCESSENTRY32W()
        entry.dwSize = ctypes.sizeof(entry)
        ok = _Process32FirstW(snap, ctypes.byref(entry))
        while ok:
            result[int(entry.th32ProcessID)] = int(entry.th32ParentProcessID)
            ok = _Process32NextW(snap, ctypes.byref(entry))
    finally:
        _CloseHandle(snap)
    return result


def is_pid_alive(pid: int) -> bool:
    if not IS_WINDOWS or pid <= 0:
        return False
    handle = _OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not handle:
        return ctypes.get_last_error() == ERROR_ACCESS_DENIED
    try:
        code = wintypes.DWORD(0)
        if not _GetExitCodeProcess(handle, ctypes.byref(code)):
            return False
        return code.value == STILL_ACTIVE
    finally:
        _CloseHandle(handle)


# --------------------------------------------------------------------------
# Instancia unica
# --------------------------------------------------------------------------
def try_acquire_mutex(name: str) -> Tuple[Optional[int], bool]:
    """
    Crea un mutex con nombre. Devuelve (handle, ya_existia).
    Si ya_existia es True otra instancia lo tiene tomado.
    """
    if not IS_WINDOWS:
        return None, False
    handle = _CreateMutexW(None, False, name)
    already = ctypes.get_last_error() == ERROR_ALREADY_EXISTS
    return (int(handle) if handle else None), already


def release_handle(handle: Optional[int]) -> None:
    if IS_WINDOWS and handle:
        _CloseHandle(handle)
