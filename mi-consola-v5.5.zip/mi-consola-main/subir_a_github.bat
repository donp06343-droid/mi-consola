@echo off
REM Sube esta carpeta a main de mi-consola. Lo que hay aca REEMPLAZA lo que hay en main.
cd /d "%~dp0"
where git >nul 2>&1 || (echo Instala Git: https://git-scm.com & pause & exit /b 1)
if not exist ".git" (
    git init -b main
    git remote add origin https://github.com/donp06343-droid/mi-consola.git
    git fetch origin
    REM Toma el historial de main SIN tocar tus archivos locales (sin conflictos)
    git reset origin/main
)
git add -A
git commit -m "v5.2: shadPS4, emuladores con .7z, tienda con categorias, Azahar/Eden"
git push -u origin main
if errorlevel 1 (
    echo.
    echo El push fallo. Si main tiene cambios nuevos, avisame antes de forzar nada.
)
pause
