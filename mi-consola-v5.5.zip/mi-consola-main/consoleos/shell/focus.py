"""
Gestor de foco y de "juego en curso".

Problema que resuelve
---------------------
1. El launcher es 'siempre encima'. Si lo fuera tambien mientras corre un
   emulador, taparia su ventana. Al lanzar un juego se quita 'siempre encima'
   y al terminar se vuelve a poner y se recupera el foco.
2. Hay que saber CUANDO termina un juego. Un Popen no basta: muchos emuladores
   y launchers (RetroBat, Steam...) abren un proceso que lanza otro y se cierra.
   Por eso se vigila el ARBOL de procesos: el juego sigue "en curso" mientras
   viva cualquier descendiente del proceso lanzado, aunque el padre ya haya
   muerto (Windows conserva el pid del padre en los hijos).
3. Lanzamientos sin proceso propio (steam://, abrir un navegador) usan un
   modo "externo": ventana de gracia y, despues, mientras el primer plano
   sea una ventana ajena al launcher y a la shell.

Redes de seguridad para no dejar al usuario atrapado
----------------------------------------------------
* Si el launcher lleva mas de FOREGROUND_GRACE_SECONDS "en juego" pero esta
  de nuevo en primer plano de forma sostenida, se da el juego por terminado
  (cubre procesos huerfanos que siguen vivos sin ventana).
* La entrada solo se bloquea mientras el foco no es del launcher
  (ver KioskController.input_locked).
"""
from __future__ import annotations

import os
import threading
import time
from collections import defaultdict
from typing import Dict, List, Optional, Set

from consoleos.log import get_logger
from consoleos.shell import winapi

log = get_logger("focus")

_SHELL_CLASSES = {"Shell_TrayWnd", "Shell_SecondaryTrayWnd", "Progman", "WorkerW"}


class FocusManager:
    POLL_SECONDS = 0.75
    MIN_RUN_SECONDS = 3.0               # no evaluar el final antes (el proceso aun arranca)
    FOREGROUND_GRACE_SECONDS = 40.0     # tiempo maximo "legitimo" de carga sin ventana propia
    OURS_FOREGROUND_SECONDS = 2.0
    IDLE_TICKS_TO_END = 2               # lecturas consecutivas "sin juego" para darlo por terminado
    LAUNCH_GUARD_SECONDS = 2.0          # tras lanzar, ignorar entrada (evita doble lanzamiento)

    def __init__(self, hwnd: int, manage_topmost: bool = True) -> None:
        self.hwnd = hwnd
        self.overlay_open = False       # menu del sistema visible: no aplicar la red de seguridad
        self._manage_topmost = manage_topmost
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

        self._running = False
        self._roots: Set[int] = set()
        self._ext_active = False
        self._ext_deadline = 0.0
        self._started_at = 0.0
        self._idle_ticks = 0
        self._ours_since: Optional[float] = None

    # ---------------------------------------------------------------- estado
    @property
    def game_running(self) -> bool:
        return self._running

    def in_launch_guard(self) -> bool:
        return self._running and (time.monotonic() - self._started_at) < self.LAUNCH_GUARD_SECONDS

    # ---------------------------------------------------------------- ciclo
    def start(self) -> None:
        if self._thread is not None:
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="consoleos-focus", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        thread, self._thread = self._thread, None
        if thread is not None and thread.is_alive():
            thread.join(timeout=2.0)

    # --------------------------------------------------------------- tracking
    def track_process(self, pid: int) -> None:
        with self._lock:
            self._roots.add(int(pid))
            self._enter()
        log.info("Juego lanzado (pid %s)", pid)

    def track_external(self, grace: float = 60.0) -> None:
        with self._lock:
            self._ext_active = True
            self._ext_deadline = time.monotonic() + grace
            self._enter()
        log.info("Lanzamiento externo (sin proceso propio), gracia %.0fs", grace)

    def bring_to_front(self) -> bool:
        self._ours_since = None
        return winapi.force_foreground(self.hwnd)

    # --------------------------------------------------------------- internos
    def _enter(self) -> None:
        self._started_at = time.monotonic()
        self._idle_ticks = 0
        self._ours_since = None
        if not self._running:
            self._running = True
            if self._manage_topmost:
                winapi.set_topmost(self.hwnd, False)

    def _leave(self) -> None:
        self._running = False
        self._roots.clear()
        self._ext_active = False
        if self._manage_topmost:
            winapi.set_topmost(self.hwnd, True)
        winapi.force_foreground(self.hwnd)
        log.info("Juego terminado; foco devuelto al launcher")

    def _loop(self) -> None:
        while not self._stop.wait(self.POLL_SECONDS):
            try:
                self._tick()
            except Exception:
                log.exception("Error en el vigilante de foco")

    def _tick(self) -> None:
        with self._lock:
            if not self._running:
                return
            now = time.monotonic()
            if now - self._started_at < self.MIN_RUN_SECONDS:
                return

            alive = self._processes_alive() or self._external_alive(now)

            ours = winapi.get_foreground_window() == self.hwnd
            if ours:
                if self._ours_since is None:
                    self._ours_since = now
            else:
                self._ours_since = None

            idle = not alive
            if (alive and not self.overlay_open and self._ours_since is not None
                    and now - self._started_at > self.FOREGROUND_GRACE_SECONDS
                    and now - self._ours_since >= self.OURS_FOREGROUND_SECONDS):
                idle = True                      # proceso huerfano sin ventana

            self._idle_ticks = self._idle_ticks + 1 if idle else 0
            if self._idle_ticks >= self.IDLE_TICKS_TO_END:
                self._leave()

    def _processes_alive(self) -> bool:
        if not self._roots:
            return False
        tree = winapi.process_tree()
        children: Dict[int, List[int]] = defaultdict(list)
        for pid, ppid in tree.items():
            children[ppid].append(pid)
        stack = list(self._roots)
        seen: Set[int] = set()
        while stack:
            pid = stack.pop()
            if pid in seen:
                continue
            seen.add(pid)
            if pid in tree or children.get(pid):
                return True
        return False

    def _external_alive(self, now: float) -> bool:
        if not self._ext_active:
            return False
        if now < self._ext_deadline:
            return True
        if self._foreign_foreground():
            return True
        self._ext_active = False
        return False

    def _foreign_foreground(self) -> bool:
        fg = winapi.get_foreground_window()
        if not fg:
            return True                          # transicion entre ventanas: no decidir todavia
        if fg == self.hwnd or winapi.window_pid(fg) == os.getpid():
            return False
        return winapi.window_class(fg) not in _SHELL_CLASSES
