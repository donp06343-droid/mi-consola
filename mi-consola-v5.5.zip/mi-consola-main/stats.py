"""
Mi Consola - Estadisticas de juego

Fuentes (todo local, sin cuentas ni claves):
  - Propias  : lanzamientos, ultima vez y tiempo jugado cuando la consola controla el proceso
               (emuladores, juegos .exe, GOG, PS4). Archivo: estadisticas.json
  - Steam    : tiempo total y de las ultimas 2 semanas, leido de userdata\\<id>\\config\\localconfig.vdf
               (Playtime en minutos). Tamano en disco: SizeOnDisk del appmanifest.
  - Epic     : Epic no expone tiempo jugado en archivos locales -> solo lanzamientos / ultima vez.
"""
import json
import os
import re
import threading
import time

from config import BASE

ARCHIVO = os.path.join(BASE, "estadisticas.json")
_lock = threading.Lock()
_datos = None
_ult_guardado = [0.0]


# ---------------------------------------------------------------------------
# Estadisticas propias
# ---------------------------------------------------------------------------
def _cargar():
    global _datos
    if _datos is None:
        try:
            with open(ARCHIVO, encoding="utf-8") as f:
                _datos = json.load(f)
        except Exception:
            _datos = {}
    return _datos


def _guardar(forzar=False):
    if not forzar and time.time() - _ult_guardado[0] < 2:
        return
    try:
        os.makedirs(BASE, exist_ok=True)
        tmp = ARCHIVO + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(_datos, f, ensure_ascii=False)
        os.replace(tmp, ARCHIVO)
        _ult_guardado[0] = time.time()
    except Exception:
        pass


def get(clave):
    with _lock:
        return dict(_cargar().get(clave, {}))


def todas():
    with _lock:
        return {k: dict(v) for k, v in _cargar().items()}


def registrar_lanzamiento(clave):
    with _lock:
        d = _cargar().setdefault(clave, {"lanzamientos": 0, "segundos": 0})
        d["lanzamientos"] = d.get("lanzamientos", 0) + 1
        d["ultimo"] = time.time()
        d.setdefault("primero", d["ultimo"])
        _guardar(True)


def sumar_tiempo(clave, seg):
    if seg < 5:                       # ignorar arranques fallidos / cierres inmediatos
        return
    with _lock:
        d = _cargar().setdefault(clave, {"lanzamientos": 0, "segundos": 0})
        d["segundos"] = d.get("segundos", 0) + int(seg)
        d["ultimo"] = time.time()
        _guardar(True)


def seguir_proceso(clave, proc):
    """Suma al total el tiempo que el proceso estuvo abierto."""
    def _esperar():
        t0 = time.time()
        try:
            proc.wait()
        except Exception:
            return
        sumar_tiempo(clave, time.time() - t0)
    threading.Thread(target=_esperar, daemon=True).start()


# ---------------------------------------------------------------------------
# Formato
# ---------------------------------------------------------------------------
def fmt_tiempo(seg):
    seg = int(seg or 0)
    if seg < 60:
        return "menos de 1 min" if seg else "0 min"
    h, m = divmod(seg // 60, 60)
    return f"{h} h {m:02d} min" if h else f"{m} min"


def fmt_hace(ts):
    if not ts:
        return "nunca"
    d = max(0, time.time() - ts)
    if d < 3600:
        return "hace minutos"
    if d < 86400:
        return f"hace {int(d // 3600)} h"
    dias = int(d // 86400)
    if dias < 60:
        return f"hace {dias} dia" + ("s" if dias != 1 else "")
    return f"hace {dias // 30} meses"


# ---------------------------------------------------------------------------
# Steam: localconfig.vdf (tiempo jugado)
# ---------------------------------------------------------------------------
def parse_vdf(texto):
    """Parser minimo de VDF de texto. Claves en minusculas (Steam mezcla mayusculas)."""
    toks = re.findall(r'"((?:[^"\\]|\\.)*)"|([{}])', texto)
    pos = [0]

    def obj():
        d = {}
        while pos[0] < len(toks):
            k, brace = toks[pos[0]]
            pos[0] += 1
            if brace == "}":
                return d
            if brace == "{" or pos[0] >= len(toks):
                continue
            v, brace2 = toks[pos[0]]
            if brace2 == "{":
                pos[0] += 1
                d[k.lower()] = obj()
            else:
                d[k.lower()] = v
                pos[0] += 1
        return d
    return obj()


_steam_cache = {"t": 0.0, "datos": {}}


def _localconfig_steam():
    import stores
    mejor, mt = None, 0
    for b in stores._carpetas_steam():
        ud = os.path.join(os.path.dirname(b), "userdata")
        if not os.path.isdir(ud):
            continue
        for u in os.listdir(ud):
            p = os.path.join(ud, u, "config", "localconfig.vdf")
            if os.path.exists(p) and os.path.getmtime(p) > mt:
                mejor, mt = p, os.path.getmtime(p)
    return mejor


def steam_tiempos():
    """{appid: {'min': total, 'min2w': ultimas 2 semanas}} (cache 60 s)."""
    if time.time() - _steam_cache["t"] < 60:
        return _steam_cache["datos"]
    datos = {}
    try:
        p = _localconfig_steam()
        if p:
            with open(p, encoding="utf-8", errors="ignore") as f:
                cfg = parse_vdf(f.read())
            apps = cfg["userlocalconfigstore"]["software"]["valve"]["steam"]["apps"]
            for appid, a in apps.items():
                if isinstance(a, dict):
                    datos[appid] = {"min": int(a.get("playtime") or 0),
                                    "min2w": int(a.get("playtime2wks") or 0)}
    except Exception:
        pass
    _steam_cache.update(t=time.time(), datos=datos)
    return datos


# ---------------------------------------------------------------------------
# Tamano en disco (en segundo plano, con cache)
# ---------------------------------------------------------------------------
_tam = {}


def _calcular_tam(ruta):
    total, n = 0, 0
    for r, _ds, fs in os.walk(ruta):
        for f in fs:
            try:
                total += os.path.getsize(os.path.join(r, f))
            except OSError:
                pass
            n += 1
            if n > 60000:
                return total
    return total


def tamano(clave, ruta):
    """Bytes o None si aun no se calculo (lo calcula en un hilo)."""
    if clave in _tam:
        return _tam[clave]
    if not ruta or "://" in str(ruta) or not os.path.exists(ruta):
        return None
    _tam[clave] = None

    def _t():
        try:
            base = ruta if os.path.isdir(ruta) else os.path.dirname(ruta)
            _tam[clave] = _calcular_tam(base) if os.path.isdir(ruta) else os.path.getsize(ruta)
        except Exception:
            pass
    threading.Thread(target=_t, daemon=True).start()
    return None


# ---------------------------------------------------------------------------
# Resumen para la UI
# ---------------------------------------------------------------------------
def resumen(sis, nom, ruta, appid, clave, con_tamano=True):
    """Dict listo para mostrar: tiempo (seg o None), tiempo_2sem, ultimo, lanzamientos, tamano, fuente."""
    import stores
    d = get(clave)
    out = {"tiempo": d.get("segundos") or None, "ultimo": d.get("ultimo"),
           "lanzamientos": d.get("lanzamientos", 0), "tiempo_2sem": None,
           "tamano": None, "fuente": "consola"}
    if sis == "Steam" and appid:
        st = steam_tiempos().get(str(appid))
        if st and st["min"]:
            out["tiempo"], out["fuente"] = st["min"] * 60, "Steam"
            out["tiempo_2sem"] = st["min2w"] * 60
        info = stores.INFO_STEAM.get(str(appid), {})
        out["tamano"] = info.get("size")
    if out["tamano"] is None and con_tamano:
        out["tamano"] = tamano(clave, ruta)
    if sis == "Epic" and not out["tiempo"]:
        out["fuente"] = "Epic no informa tiempo"
    return out


_glob = {"t": 0.0, "n": -1, "v": None}


def resumen_global(juegos, clave_fn):
    """Totales para la pantalla de estadisticas generales (cacheado 2 s: se dibuja cada frame)."""
    if _glob["v"] is not None and _glob["n"] == len(juegos) and time.time() - _glob["t"] < 2:
        return _glob["v"]
    por_sis, tiempos = {}, []
    total = 0
    for sis, nom, ruta, appid in juegos:
        por_sis[sis] = por_sis.get(sis, 0) + 1
        r = resumen(sis, nom, ruta, appid, clave_fn(sis, nom), con_tamano=False)
        t = r["tiempo"] or 0
        total += t
        tiempos.append((t, r["ultimo"] or 0, sis, nom))
    mas = sorted([x for x in tiempos if x[0] > 0], reverse=True)[:6]
    recientes = sorted([x for x in tiempos if x[1] > 0], key=lambda x: x[1], reverse=True)[:6]
    v = {"por_sistema": dict(sorted(por_sis.items(), key=lambda kv: -kv[1])),
         "total_juegos": len(juegos), "tiempo_total": total, "mas_jugados": mas, "recientes": recientes}
    _glob.update(t=time.time(), n=len(juegos), v=v)
    return v
