"""
Ocultar y restaurar la barra de tareas de Windows.

Windows 10/11 dibuja una barra por monitor: 'Shell_TrayWnd' (principal) y
'Shell_SecondaryTrayWnd' (resto). Se ocultan todas con ShowWindow(SW_HIDE).

Un hilo guardia revisa cada 1,5 s que sigan ocultas: la barra reaparece sola
cuando explorer.exe se reinicia o cuando una notificacion roba el foco.

Cuando explorer.exe no esta corriendo (shell reemplazado) no hay nada que
ocultar y todo este modulo es un no-op.
"""
from __future__ import annotations

import threading
from typing import List, Optional, Set

from consoleos.log import get_logger
from consoleos.shell import winapi

log = get_logger("taskbar")

_TRAY_CLASSES = ("Shell_TrayWnd", "Shell_SecondaryTrayWnd")


def _find_all() -> List[int]:
    found: List[int] = []
    for cls in _TRAY_CLASSES:
        found.extend(winapi.find_windows_by_class(cls))
    return found


class TaskbarController:
    def __init__(self) -> None:
        self._hidden: Set[int] = set()
        self._stop = threading.Event()
        self._guard: Optional[threading.Thread] = None

    def hide(self) -> int:
        count = 0
        for hwnd in _find_all():
            if winapi.show_window(hwnd, winapi.SW_HIDE) or not winapi.is_window_visible(hwnd):
                self._hidden.add(hwnd)
                count += 1
        log.info("Barra(s) de tareas ocultas: %d", count)
        return count

    def start_guard(self, interval: float = 1.5) -> None:
        if self._guard is not None:
            return
        self._stop.clear()

        def _loop() -> None:
            while not self._stop.wait(interval):
                try:
                    for hwnd in _find_all():
                        if winapi.is_window_visible(hwnd):
                            winapi.show_window(hwnd, winapi.SW_HIDE)
                            self._hidden.add(hwnd)
                except Exception:  # el guardia nunca debe morir por un error puntual
                    log.exception("Error en el guardia de la barra de tareas")

        self._guard = threading.Thread(target=_loop, name="consoleos-taskbar", daemon=True)
        self._guard.start()

    def restore(self) -> None:
        self._stop.set()
        guard, self._guard = self._guard, None
        if guard is not None and guard.is_alive():
            guard.join(timeout=2.0)
        self.restore_all()
        self._hidden.clear()

    @staticmethod
    def restore_all() -> int:
        """Muestra todas las barras existentes. Tambien sirve para recuperar tras un fallo."""
        count = 0
        for hwnd in _find_all():
            winapi.show_window(hwnd, winapi.SW_SHOW)
            count += 1
        log.info("Barra(s) de tareas restauradas: %d", count)
        return count
