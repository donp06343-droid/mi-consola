"""
Mi Consola v5 - Punto de entrada modular
Lanzador a pantalla completa + centro de descargas.
"""
import os
import sys
import time
import threading
import webbrowser

import pygame

from config import (
    NOMBRE, BASE, JUEGOS, DESTINOS,
    FONDO, PANEL, PANEL2, TEXTO, SUAVE, AZUL, VERDE, ROJO, DORADO, CIAN, MORADO,
)
MORADO_T = MORADO
from library import (
    cargar_cfg, escanear, detectar_pc,
    cargar_favoritos, guardar_favoritos, clave_juego,
)
from launcher import jugar, abrir_shadps4_gui
import stats
from covers import cache_portadas, buscar_portada_local, pedir_portada
from downloads import (cola, agregar_enlaces, leer_portapapeles, alternar_pausa, quitar,
                       limpiar_completadas, ciclar_limite, texto_limite, velocidad_total,
                       fmt_bytes, fmt_vel, fmt_eta, eta_item, espacio_libre)
from store import TIENDA, CATEGORIAS, filtrar, pedir
from controls import (
    ACCIONES, TECLAS_DEFECTO, JOY_DEFECTO,
    cargar_controles, guardar_controles,
    nombre_tecla, key_to_name,
)
from ui.stars import Estrellas
from ui.cards import dibujar_tarjeta
from consoleos import Mode
from consoleos.shell import kiosk, EV_ESCAPE
from consoleos.shell.system_menu import SystemMenu


def mb(b):
    if b < 1 << 20:
        return f"{b / 1024:.0f} KB"
    if b < 1 << 30:
        return f"{b / 1048576:.0f} MB"
    return f"{b / (1 << 30):.1f} GB"


def tamano_ruta(ruta):
    try:
        if os.path.isfile(ruta):
            return os.path.getsize(ruta)
        if os.path.isdir(ruta):
            total = 0
            for r, _, fs in os.walk(ruta):
                for f in fs:
                    try:
                        total += os.path.getsize(os.path.join(r, f))
                    except Exception:
                        pass
            return total
    except Exception:
        pass
    return 0


def main():
    # Capa 1 (Consola OS): decide el modo y prepara SDL antes de pygame.init().
    if not kiosk.prepare(Mode.from_argv(sys.argv)):
        print("Mi Consola ya se esta ejecutando en modo consola.")
        return

    pygame.init()
    pygame.joystick.init()
    pygame.event.pump()

    joysticks = {}
    def init_joysticks():
        joysticks.clear()
        for i in range(pygame.joystick.get_count()):
            try:
                j = pygame.joystick.Joystick(i)
                j.init()
                joysticks[j.get_instance_id()] = j
            except Exception:
                pass
    init_joysticks()

    pantalla = pygame.display.set_mode((1280, 720), pygame.SCALED | pygame.FULLSCREEN)
    pygame.display.set_caption(NOMBRE)
    pygame.mouse.set_visible(False)
    kiosk.start()   # no-op en modo normal

    f_tit = pygame.font.SysFont("segoeui", 38, bold=True)
    f_med = pygame.font.SysFont("segoeui", 22)
    f_peq = pygame.font.SysFont("segoeui", 17)
    f_mini = pygame.font.SysFont("segoeui", 14)
    menu = SystemMenu(kiosk, f_tit, f_med, f_peq, f_mini)

    cfg = cargar_cfg()
    map_teclas, map_joy = cargar_controles()
    favoritos = cargar_favoritos()
    reloj = pygame.time.Clock()

    vista, sel, sel_d, dest_i, aviso = "inicio", 0, 0, 0, ""
    sel_t = sel_c = sel_cat = 0
    esperando = None
    COLS = 5
    estrellas = Estrellas(1280, 720, 140)
    t_aviso = 0
    last_axis = {"x": 0, "y": 0, "t": 0}
    juegos, t_scan = [], 0
    modo_busqueda = False
    texto_busqueda = ""
    orden = "nombre"
    juegos_filtrados = []
    portadas_cache = {}
    t_portadas = 0

    def txt(s, f, c, x, y, centro=False):
        im = f.render(str(s), True, c)
        pantalla.blit(im, im.get_rect(center=(x, y)) if centro else (x, y))
        return im.get_width()

    def set_aviso(msg, dur=4.0):
        nonlocal aviso, t_aviso
        aviso = msg
        t_aviso = time.time() + dur

    def resolver_tecla(key_const):
        nombre = key_to_name(key_const)
        for acc, keys in map_teclas.items():
            if nombre in keys:
                return acc
        return None

    def resolver_joy(button):
        for acc, buttons in map_joy.items():
            if button in buttons:
                return acc
        return None

    def filtrar_y_ordenar():
        nonlocal juegos_filtrados, sel
        lista = list(juegos)
        if texto_busqueda.strip():
            q = texto_busqueda.lower().strip()
            lista = [j for j in lista if q in j[1].lower() or q in j[0].lower()]
        if orden == "nombre":
            lista.sort(key=lambda x: x[1].lower())
        elif orden == "sistema":
            lista.sort(key=lambda x: (x[0].lower(), x[1].lower()))
        elif orden == "favoritos":
            lista.sort(key=lambda x: (0 if clave_juego(x[0], x[1]) in favoritos else 1, x[1].lower()))
        juegos_filtrados = lista
        if sel >= len(juegos_filtrados):
            sel = max(0, len(juegos_filtrados) - 1)

    while True:
        dt = reloj.tick(30) / 1000.0
        ahora = time.time()
        if ahora - t_scan > 2.5:
            juegos = escanear()
            t_scan = ahora
            t_portadas = ahora
            filtrar_y_ordenar()

        for e in pygame.event.get():
            tecla = None
            # Capa 1: el kiosk consume eventos de sistema y la entrada del mando
            # mientras hay un juego en primer plano.
            if kiosk.handle_event(e):
                continue
            if e.type == EV_ESCAPE:
                # Combinacion secreta: pedir PIN para salir al escritorio.
                modo_busqueda = False
                esperando = None
                menu.open(pin_direct=True)
                continue
            if e.type == pygame.QUIT:
                return
            if e.type in (pygame.JOYDEVICEADDED, pygame.JOYDEVICEREMOVED):
                init_joysticks()

            if menu.visible and menu.handle_key(e):
                continue

            if modo_busqueda:
                if e.type == pygame.KEYDOWN:
                    if e.key == pygame.K_ESCAPE:
                        modo_busqueda = False
                        texto_busqueda = ""
                        filtrar_y_ordenar()
                        set_aviso("Busqueda cancelada")
                    elif e.key == pygame.K_RETURN:
                        modo_busqueda = False
                        filtrar_y_ordenar()
                        set_aviso(f"Filtro: <<{texto_busqueda}>>" if texto_busqueda else "Filtro quitado")
                    elif e.key == pygame.K_BACKSPACE:
                        texto_busqueda = texto_busqueda[:-1]
                        filtrar_y_ordenar()
                    else:
                        ch = e.unicode
                        if ch and ch.isprintable() and len(texto_busqueda) < 40:
                            texto_busqueda += ch
                            filtrar_y_ordenar()
                continue

            if esperando:
                tipo, accion = esperando
                if e.type == pygame.KEYDOWN:
                    if e.key == pygame.K_ESCAPE:
                        esperando = None
                        set_aviso("Cancelado")
                        continue
                    nombre = key_to_name(e.key)
                    for a in map_teclas:
                        if nombre in map_teclas[a]:
                            map_teclas[a].remove(nombre)
                    map_teclas[accion] = [nombre]
                    guardar_controles(map_teclas, map_joy)
                    esperando = None
                    set_aviso(f"Reasignado -> {nombre_tecla(nombre)}")
                    continue
                if e.type == pygame.JOYBUTTONDOWN and tipo == "joy":
                    btn = e.button
                    for a in map_joy:
                        if btn in map_joy[a]:
                            map_joy[a].remove(btn)
                    map_joy[accion] = [btn]
                    guardar_controles(map_teclas, map_joy)
                    esperando = None
                    set_aviso(f"Reasignado -> Boton {btn}")
                    continue
                continue

            if e.type == pygame.KEYDOWN:
                tecla = resolver_tecla(e.key)
            elif e.type == pygame.JOYHATMOTION:
                tecla = {(-1, 0): "i", (1, 0): "d", (0, 1): "a", (0, -1): "b"}.get(e.value)
            elif e.type == pygame.JOYBUTTONDOWN:
                tecla = resolver_joy(e.button)
            elif e.type == pygame.JOYAXISMOTION:
                if ahora - last_axis["t"] > 0.22:
                    if e.axis == 0:
                        if e.value < -0.55:
                            tecla = "i"
                            last_axis = {"x": e.value, "y": 0, "t": ahora}
                        elif e.value > 0.55:
                            tecla = "d"
                            last_axis = {"x": e.value, "y": 0, "t": ahora}
                    elif e.axis == 1:
                        if e.value < -0.55:
                            tecla = "a"
                            last_axis = {"x": 0, "y": e.value, "t": ahora}
                        elif e.value > 0.55:
                            tecla = "b"
                            last_axis = {"x": 0, "y": e.value, "t": ahora}

            if not tecla:
                continue
            if menu.visible:
                menu.handle_action(tecla)
                continue
            if aviso and ahora > t_aviso:
                aviso = ""

            if tecla == "controles":
                vista = "controles"
                sel_c = 0
                continue
            if tecla == "stats" and vista in ("inicio", "stats"):
                vista = "stats" if vista == "inicio" else "inicio"
                continue
            if tecla == "desc":
                vista = "descargas" if vista == "inicio" else "inicio"
            elif tecla == "tienda":
                vista = "tienda"
                sel_t = 0
            elif tecla == "rescan":
                detectar_pc(forzar=True)
                portadas_cache.clear()
                set_aviso("Re-escaneando discos...")
            elif tecla == "spotify":
                try:
                    if sys.platform == "win32":
                        os.startfile("spotify:")
                    else:
                        webbrowser.open("https://open.spotify.com")
                except Exception:
                    webbrowser.open("https://open.spotify.com")
                kiosk.external_launched()
                set_aviso("Abriendo Spotify...")
            elif tecla == "shadps4" and vista == "inicio":
                msg = abrir_shadps4_gui(cfg)
                set_aviso(msg if msg else "Abriendo GUI de shadPS4 (Instalar PKG)...")
            elif tecla == "buscar" and vista == "inicio":
                modo_busqueda = True
                set_aviso("Escribi para filtrar... Enter aceptar  Esc cancelar")
            elif tecla == "ordenar" and vista == "inicio":
                ordenes = ["nombre", "sistema", "favoritos"]
                idx = ordenes.index(orden) if orden in ordenes else 0
                orden = ordenes[(idx + 1) % len(ordenes)]
                filtrar_y_ordenar()
                set_aviso(f"Orden: {orden}")
            elif tecla == "favorito" and vista == "inicio" and juegos_filtrados:
                j = juegos_filtrados[sel]
                k = clave_juego(j[0], j[1])
                if k in favoritos:
                    favoritos.discard(k)
                    set_aviso(f"Quitado de favoritos: {j[1]}")
                else:
                    favoritos.add(k)
                    set_aviso(f"* Favorito: {j[1]}")
                guardar_favoritos(favoritos)
                filtrar_y_ordenar()
            elif tecla == "atras":
                if vista in ("descargas", "tienda", "controles", "stats"):
                    vista = "inicio"
                    esperando = None
                elif kiosk.active:
                    menu.open()
                else:
                    return
            elif vista == "inicio" and juegos_filtrados:
                if tecla == "i":
                    sel = max(0, sel - 1)
                if tecla == "d":
                    sel = min(len(juegos_filtrados) - 1, sel + 1)
                if tecla == "a":
                    sel = max(0, sel - COLS)
                if tecla == "b":
                    sel = min(len(juegos_filtrados) - 1, sel + COLS)
                if tecla == "ok":
                    j = juegos_filtrados[sel]
                    k_j = clave_juego(j[0], j[1])
                    msg = jugar(j[0], j[2], cfg, k_j)
                    if msg:
                        set_aviso(msg)
                    else:
                        stats.registrar_lanzamiento(k_j)
            elif vista == "tienda":
                lista_t = filtrar(CATEGORIAS[sel_cat])
                if tecla == "i":
                    sel_cat = (sel_cat - 1) % len(CATEGORIAS)
                    sel_t = 0
                if tecla == "d":
                    sel_cat = (sel_cat + 1) % len(CATEGORIAS)
                    sel_t = 0
                lista_t = filtrar(CATEGORIAS[sel_cat])
                if tecla == "a":
                    sel_t = max(0, sel_t - 1)
                if tecla == "b":
                    sel_t = min(max(0, len(lista_t) - 1), sel_t + 1)
                if tecla == "ok" and lista_t:
                    j = lista_t[sel_t]
                    def _pedir_y_avisar(jj=j):
                        r = pedir(jj)
                        if r not in ("tienda", "web", "descarga", "error"):
                            set_aviso(r)             # mensaje de error legible
                    threading.Thread(target=_pedir_y_avisar, daemon=True).start()
                    if j.get("uri") or j.get("steam"):
                        set_aviso(f"Abriendo <<{j['n']}>> en su cliente...")
                    elif j.get("emu"):
                        set_aviso(f"Instalando <<{j['n']}>> en {os.path.join(BASE, j['emu'])} (ver Tab)")
                    else:
                        set_aviso(f"Procesando <<{j['n']}>>...")
            elif vista == "descargas":
                if tecla == "a":
                    sel_d = max(0, sel_d - 1)
                if tecla == "b":
                    sel_d = min(max(0, len(cola) - 1), sel_d + 1)
                if tecla == "dest":
                    dest_i = (dest_i + 1) % len(DESTINOS)
                if tecla == "pegar":
                    ok = agregar_enlaces(leer_portapapeles(), DESTINOS[dest_i])
                    set_aviso("Descarga agregada." if ok else "Copia un enlace http primero.")
                if cola and tecla == "pausa":
                    alternar_pausa(cola[sel_d])
                if cola and tecla == "quitar":
                    it_q = cola[sel_d]
                    quitar(it_q)
                    set_aviso("Cancelando descarga..." if it_q["estado"] in ("bajando", "reintentando") else "Quitada de la cola.")
                    sel_d = max(0, min(sel_d, len(cola) - 1))
                if tecla == "limite":
                    set_aviso(f"Limite de velocidad: {ciclar_limite()}")
                if tecla == "limpiar":
                    set_aviso(f"{limpiar_completadas()} completada(s) quitadas.")
                    sel_d = max(0, min(sel_d, len(cola) - 1))
            elif vista == "controles":
                n_acc = len(ACCIONES)
                if tecla == "a":
                    sel_c = max(0, sel_c - 1)
                if tecla == "b":
                    sel_c = min(n_acc * 2 + 1, sel_c + 1)
                if tecla == "ok":
                    if sel_c < n_acc:
                        accion = ACCIONES[sel_c][0]
                        esperando = ("teclado", accion)
                        set_aviso(f"Pulsa una TECLA para <<{ACCIONES[sel_c][1]}>>")
                    elif sel_c < n_acc * 2:
                        idx = sel_c - n_acc
                        accion = ACCIONES[idx][0]
                        esperando = ("joy", accion)
                        set_aviso(f"Pulsa un BOTON para <<{ACCIONES[idx][1]}>>")
                    else:
                        map_teclas = {k: list(v) for k, v in TECLAS_DEFECTO.items()}
                        map_joy = {k: list(v) for k, v in JOY_DEFECTO.items()}
                        guardar_controles(map_teclas, map_joy)
                        set_aviso("Controles restaurados")

        if menu.should_quit:
            return

        # ---- dibujo ----
        pantalla.fill(FONDO)
        estrellas.update(dt)
        estrellas.draw(pantalla)

        for i in range(110):
            t = i / 110
            col = (
                min(255, int(FONDO[0] + 18 * (1 - t))),
                min(255, int(FONDO[1] + 28 * (1 - t))),
                min(255, int(FONDO[2] + 55 * (1 - t))),
            )
            pygame.draw.line(pantalla, col, (0, i), (1280, i))

        pygame.draw.line(pantalla, (40, 90, 160), (40, 72), (1240, 72), 1)
        pygame.draw.line(pantalla, (255, 190, 60), (40, 73), (280, 73), 2)

        sombra = f_tit.render(NOMBRE, True, (0, 10, 30))
        pantalla.blit(sombra, (57, 20))
        txt(NOMBRE, f_tit, TEXTO, 55, 18)
        txt(time.strftime("%H:%M"), f_med, SUAVE, 1165, 22)

        if joysticks:
            txt(f"Gamepad x{len(joysticks)}", f_mini, VERDE, 1040, 28)
        else:
            txt("Sin gamepad", f_mini, SUAVE, 1040, 28)
        txt("Spotify", f_mini, (30, 215, 96), 920, 28)

        activas = [i for i in cola if i["estado"] in ("bajando", "en cola", "reintentando", "extrayendo")]
        if activas and vista == "inicio":
            vt = velocidad_total()
            txt(f"v {len(activas)} descarga(s)" + (f"  .  {fmt_vel(vt)}" if vt else "") + "  .  Tab", f_peq, VERDE, 55, 62)

        pie = ""
        if vista == "inicio":
            n_total = len(juegos)
            n_filtro = len(juegos_filtrados)
            info_barra = f"{n_filtro}/{n_total} juegos"
            if texto_busqueda:
                info_barra += f"  .  <<{texto_busqueda}>>"
            info_barra += f"  .  orden: {orden}"
            txt(info_barra, f_peq, SUAVE, 55, 88)

            if not juegos_filtrados:
                if not juegos:
                    txt("Todavia no hay juegos detectados", f_tit, TEXTO, 640, 280, True)
                    txt(f"ROMs ->  {JUEGOS}\\NES  \\SNES  \\N64  \\PS1  etc.", f_med, SUAVE, 640, 340, True)
                    txt("PC -> apreta R para escanear   .   Tab = descargas   .   T = tienda", f_peq, SUAVE, 640, 390, True)
                else:
                    txt("Ningun juego coincide con el filtro", f_tit, TEXTO, 640, 300, True)
            else:
                fila_sel = sel // COLS
                for n, (sis, nom, ruta, appid) in enumerate(juegos_filtrados):
                    fila, col = n // COLS, n % COLS
                    y = 120 + (fila - max(0, fila_sel - 1)) * 280
                    if y < 100 or y > 680:
                        continue
                    x = 40 + col * 245
                    es_fav = clave_juego(sis, nom) in favoritos
                    dibujar_tarjeta(
                        pantalla, x, y, 220, 250, sis, nom, ruta, appid,
                        n == sel, es_fav, portadas_cache, f_peq, f_mini, ahora, t_portadas
                    )

                if juegos_filtrados:
                    j = juegos_filtrados[sel]
                    sis, nom, ruta, appid = j
                    panel = pygame.Rect(960, 470, 300, 205)
                    pygame.draw.rect(pantalla, PANEL, panel, border_radius=10)
                    pygame.draw.rect(pantalla, AZUL, panel, 1, border_radius=10)
                    k_sel = clave_juego(sis, nom)
                    rs = stats.resumen(sis, nom, ruta, appid, k_sel)
                    txt(nom[:30], f_peq, TEXTO, 975, 480)
                    txt(f"{sis}" + (f"  .  AppID {appid}" if appid else ""), f_mini, CIAN, 975, 506)
                    if rs["tiempo"]:
                        txt(f"Jugado: {stats.fmt_tiempo(rs['tiempo'])}", f_mini, VERDE, 975, 530)
                    else:
                        txt("Jugado: sin datos" + (f" ({rs['fuente']})" if sis == "Epic" else ""), f_mini, SUAVE, 975, 530)
                    if rs["tiempo_2sem"]:
                        txt(f"Ultimas 2 semanas: {stats.fmt_tiempo(rs['tiempo_2sem'])}", f_mini, SUAVE, 975, 550)
                    txt(f"Ultima vez: {stats.fmt_hace(rs['ultimo'])}  .  {rs['lanzamientos']} inicio(s)", f_mini, SUAVE, 975, 570)
                    txt(f"Tamano: {mb(rs['tamano'])}" if rs["tamano"] else "Tamano: calculando...", f_mini, SUAVE, 975, 590)
                    es_fav = k_sel in favoritos
                    txt("* Favorito" if es_fav else "F = marcar favorito", f_mini, DORADO if es_fav else SUAVE, 975, 612)
                    txt("H = estadisticas generales", f_mini, SUAVE, 975, 640)

            etiqueta_esc = "Esc sistema" if kiosk.active else "Esc salir"
            pie = "Enter jugar  F favorito  / buscar  O orden  T tienda  G shadPS4  H stats  Tab descargas  M Spotify  C controles  R re-escanear  " + etiqueta_esc
            if modo_busqueda:
                pygame.draw.rect(pantalla, (30, 20, 50), (40, 650, 1200, 40), border_radius=8)
                txt(f"Buscar: {texto_busqueda}_", f_med, DORADO, 55, 658)

        elif vista == "tienda":
            lista_t = filtrar(CATEGORIAS[sel_cat])
            sel_t = min(sel_t, max(0, len(lista_t) - 1))
            txt("Tienda  .  juegos gratis y legales", f_med, TEXTO, 55, 85)
            txt(f"{len(lista_t)}/{len(TIENDA)} titulos  .  open-source / free-to-play / emuladores", f_peq, SUAVE, 55, 115)
            # Pestanas de categoria (izq/der para cambiar)
            cx = 560
            for ci, cname in enumerate(CATEGORIAS):
                w = f_mini.size(cname)[0] + 22
                if cx + w > 1240:
                    break
                rc = pygame.Rect(cx, 98, w, 26)
                pygame.draw.rect(pantalla, AZUL if ci == sel_cat else PANEL, rc, border_radius=13)
                txt(cname, f_mini, TEXTO if ci == sel_cat else SUAVE, rc.centerx, rc.centery, True)
                cx += w + 6
            top = max(0, sel_t - 4)
            for n, j in enumerate(lista_t):
                if n < top or n > top + 5:
                    continue
                y = 150 + (n - top) * 85
                r = pygame.Rect(50, y, 1180, 76)
                pygame.draw.rect(pantalla, PANEL if n != sel_t else PANEL2, r, border_radius=12)
                if n == sel_t:
                    pygame.draw.rect(pantalla, AZUL, r, 3, border_radius=12)
                txt(j["n"], f_med, TEXTO, 70, y + 10)
                txt(j["d"][:90], f_peq, SUAVE, 70, y + 42)
                if j.get("uri"):
                    etiqueta, color_e = "Abrir tienda", DORADO
                elif j.get("emu"):
                    etiqueta, color_e = "Instalar", MORADO_T
                elif j.get("pago"):
                    etiqueta, color_e = "Comprar", DORADO
                elif j.get("dl") or j.get("repo"):
                    etiqueta, color_e = "Descargar", VERDE
                elif j.get("steam"):
                    etiqueta, color_e = "Steam (gratis)", AZUL
                else:
                    etiqueta, color_e = "Pagina oficial", CIAN
                txt(etiqueta, f_peq, color_e, 1020, y + 28)
            pie = "Enter bajar/abrir   arriba/abajo mover   izq/der categoria   Tab descargas   Esc volver"

        elif vista == "stats":
            g = stats.resumen_global(juegos, clave_juego)
            txt("Estadisticas", f_med, TEXTO, 55, 85)
            txt(f"{g['total_juegos']} juegos  .  {stats.fmt_tiempo(g['tiempo_total'])} jugados en total", f_peq, SUAVE, 55, 118)
            txt("POR TIENDA / SISTEMA", f_mini, DORADO, 60, 160)
            mx = max(g["por_sistema"].values()) if g["por_sistema"] else 1
            for n, (nom_s, cant) in enumerate(list(g["por_sistema"].items())[:12]):
                yy = 188 + n * 36
                txt(nom_s[:14], f_peq, TEXTO, 60, yy)
                pygame.draw.rect(pantalla, PANEL, (200, yy + 4, 300, 16), border_radius=8)
                pygame.draw.rect(pantalla, AZUL, (200, yy + 4, max(4, int(300 * cant / mx)), 16), border_radius=8)
                txt(str(cant), f_mini, SUAVE, 510, yy + 3)
            txt("MAS JUGADOS", f_mini, DORADO, 640, 160)
            if not g["mas_jugados"]:
                txt("Todavia sin datos: jugando se va llenando", f_mini, SUAVE, 640, 188)
            for n, (t_s, _u, sis_s, nom_s) in enumerate(g["mas_jugados"]):
                txt(f"{n + 1}. {nom_s[:26]}", f_peq, TEXTO, 640, 188 + n * 30)
                txt(stats.fmt_tiempo(t_s), f_mini, VERDE, 1090, 192 + n * 30)
            txt("JUGADOS RECIENTEMENTE", f_mini, DORADO, 640, 400)
            for n, (_t, u_s, sis_s, nom_s) in enumerate(g["recientes"]):
                txt(f"{nom_s[:26]}", f_peq, TEXTO, 640, 428 + n * 30)
                txt(stats.fmt_hace(u_s), f_mini, SUAVE, 1090, 432 + n * 30)
            pie = "H / Esc volver"

        elif vista == "controles":
            txt("Configuracion de controles", f_med, TEXTO, 55, 80)
            if esperando:
                tipo, acc = esperando
                nombre_acc = next((n for a, n in ACCIONES if a == acc), acc)
                msg = f"Esperando {'TECLA' if tipo == 'teclado' else 'BOTON'} para <<{nombre_acc}>>"
                pygame.draw.rect(pantalla, (40, 20, 60), (50, 115, 1180, 40), border_radius=8)
                txt(msg, f_peq, DORADO, 640, 125, True)
            else:
                txt("Enter = reasignar   .   Esc = volver", f_peq, SUAVE, 55, 112)
            n_acc = len(ACCIONES)
            top = max(0, min(sel_c, n_acc * 2) // 2 - 4)
            for i, (acc, nombre) in enumerate(ACCIONES):
                y = 160 + (i - top) * 36
                if 160 <= y <= 580:
                    sel_izq = (sel_c == i)
                    r = pygame.Rect(50, y, 560, 32)
                    pygame.draw.rect(pantalla, PANEL2 if sel_izq else PANEL, r, border_radius=6)
                    if sel_izq:
                        pygame.draw.rect(pantalla, AZUL, r, 2, border_radius=6)
                    keys = map_teclas.get(acc, [])
                    keys_str = ", ".join(nombre_tecla(k) for k in keys) if keys else "-"
                    txt(nombre, f_peq, TEXTO, 60, y + 6)
                    txt(keys_str, f_peq, VERDE if keys else SUAVE, 320, y + 6)
                y2 = 160 + (i - top) * 36
                if 160 <= y2 <= 580:
                    sel_der = (sel_c == n_acc + i)
                    r2 = pygame.Rect(640, y2, 560, 32)
                    pygame.draw.rect(pantalla, PANEL2 if sel_der else PANEL, r2, border_radius=6)
                    if sel_der:
                        pygame.draw.rect(pantalla, AZUL, r2, 2, border_radius=6)
                    btns = map_joy.get(acc, [])
                    btns_str = ", ".join(f"Btn {b}" for b in btns) if btns else "-"
                    txt(nombre, f_peq, TEXTO, 650, y2 + 6)
                    txt(btns_str, f_peq, CIAN if btns else SUAVE, 920, y2 + 6)
            y_reset = 160 + (n_acc - top) * 36 + 10
            if y_reset < 620:
                sel_reset = (sel_c == n_acc * 2)
                r3 = pygame.Rect(50, y_reset, 1150, 36)
                pygame.draw.rect(pantalla, (60, 30, 30) if sel_reset else PANEL, r3, border_radius=8)
                if sel_reset:
                    pygame.draw.rect(pantalla, ROJO, r3, 2, border_radius=8)
                txt("Restaurar controles por defecto", f_med, ROJO if sel_reset else SUAVE, 640, y_reset + 6, True)
            txt("TECLADO", f_mini, DORADO, 60, 145)
            txt("JOYSTICK / GAMEPAD", f_mini, DORADO, 650, 145)
            pie = "flechas mover   Enter reasignar   Esc volver"

        else:
            libre = espacio_libre()
            vt = velocidad_total()
            txt(f"Descargas  .  destino: {DESTINOS[dest_i]}", f_med, TEXTO, 55, 85)
            txt(f"Velocidad total: {fmt_vel(vt)}   .   Limite: {texto_limite()}   .   Libre en disco: {fmt_bytes(libre) if libre is not None else '?'}",
                f_peq, SUAVE, 55, 118)
            if not cola:
                txt("Copia un enlace (http...) y apreta V para empezar", f_med, SUAVE, 640, 300, True)
            sel_d = min(sel_d, max(0, len(cola) - 1))
            top_d = max(0, sel_d - 4)
            for n, it in enumerate(cola):
                if n < top_d or n > top_d + 5:
                    continue
                y = 145 + (n - top_d) * 88
                r = pygame.Rect(50, y, 1180, 78)
                pygame.draw.rect(pantalla, PANEL, r, border_radius=12)
                if n == sel_d:
                    pygame.draw.rect(pantalla, AZUL, r, 3, border_radius=12)
                partes = f"  (parte {it['parte']}/{len(it['urls'])})" if len(it["urls"]) > 1 else ""
                txt(it["nombre"][:48] + partes, f_med, TEXTO, 70, y + 8)
                est = it["estado"]
                pct = it["hecho"] / it["total"] if it["total"] else 0
                if est == "pausado" or it.get("pausa"):
                    est_txt, color_est = "PAUSADO", DORADO
                elif est == "error":
                    est_txt, color_est = "ERROR: " + it.get("error", ""), ROJO
                elif est == "reintentando":
                    est_txt, color_est = it.get("error") or "reintentando", DORADO
                elif est == "listo":
                    est_txt, color_est = "LISTO", VERDE
                elif est == "extrayendo":
                    est_txt, color_est = "EXTRAYENDO...", CIAN
                elif est == "en cola":
                    est_txt, color_est = "EN COLA", SUAVE
                else:
                    est_txt, color_est = f"{fmt_vel(it.get('vel', 0))}   resta {fmt_eta(eta_item(it))}", VERDE
                tam = f"{fmt_bytes(it['hecho'])} / {fmt_bytes(it['total'])}" if it["total"] else f"{fmt_bytes(it['hecho'])} (tamano desconocido)"
                txt(f"{est_txt}", f_peq, color_est, 70, y + 44)
                if est != "listo":
                    txt(f"{pct * 100:.0f}%   {tam}", f_peq, SUAVE, 720, y + 14)
                pygame.draw.rect(pantalla, FONDO, (720, y + 48, 480, 14), border_radius=7)
                wbar = int(480 * (1 if est == "listo" else pct))
                col_bar = VERDE if est == "listo" else (DORADO if est in ("pausado", "reintentando") else AZUL)
                pygame.draw.rect(pantalla, col_bar, (720, y + 48, wbar, 14), border_radius=7)
            if len(cola) > 6:
                txt(f"{sel_d + 1}/{len(cola)}", f_mini, SUAVE, 1180, 120)
            pie = "V pegar   S destino   P pausar/seguir   L limite   Supr cancelar   X limpiar listas   Tab volver"

        if aviso and ahora < t_aviso and not modo_busqueda:
            pygame.draw.rect(pantalla, (20, 10, 30), (40, 630, 1200, 36), border_radius=8)
            txt(aviso, f_med, ROJO if "Error" in aviso or "error" in aviso.lower() else DORADO, 55, 636)

        if not modo_busqueda and pie:
            txt(pie, f_peq, SUAVE, 55, 685)
        menu.draw(pantalla)
        pygame.display.flip()


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "--web":
        try:
            import webview
            webview.create_window(NOMBRE + " - Tienda", sys.argv[2], width=1280, height=720, maximized=True)
            webview.start(private_mode=False, storage_path=os.path.join(BASE, "sesion_web"))
        except ImportError:
            webbrowser.open(sys.argv[2])
    else:
        try:
            main()
        finally:
            kiosk.stop()   # restaura barra de tareas, hook y ventana (idempotente)
