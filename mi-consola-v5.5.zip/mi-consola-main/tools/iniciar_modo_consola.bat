@echo off
REM Mi Consola - Iniciar en MODO CONSOLA (kiosk)
cd /d "%~dp0.."
where pythonw >nul 2>&1
if %ERRORLEVEL%==0 (
    start "" pythonw main.py --mode console
) else (
    python main.py --mode console
)
