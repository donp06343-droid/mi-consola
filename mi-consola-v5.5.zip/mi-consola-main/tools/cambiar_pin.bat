@echo off
REM Mi Consola - Cambiar el PIN de salida al escritorio (4 digitos)
cd /d "%~dp0.."
python -m consoleos.settings set-pin
echo.
pause
