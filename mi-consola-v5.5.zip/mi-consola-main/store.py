"""
Mi Consola - Tienda de juegos gratis / legales
"""
import os
import re
import json
import sys
import subprocess
import webbrowser
import urllib.request
import threading

from config import BASE
from downloads import agregar_enlaces
from launcher import abrir_uri
from consoleos.shell import kiosk

# ---------------------------------------------------------------------------
# Catalogo: SOLO software libre / gratuito / paginas oficiales.
#   repo=  -> descarga directa desde GitHub Releases (pat = regex del asset)
#   web_dl -> abre la pagina oficial de descarga
#   steam= -> id de Steam (free-to-play): abre la pagina de la tienda
#   emu=   -> emulador: se instala en BASE\<emu>
# ---------------------------------------------------------------------------
CAT_TODOS = "Todos"
CAT_EMU = "Emuladores"
CAT_TIENDAS = "Tiendas"


def _j(cat, n, d, web, web_dl=None, repo=None, pat=None, steam=None, uri=None, **extra):
    j = dict(cat=cat, n=n, d=d, web=web, web_dl=web_dl or web)
    if steam:
        j["web"] = j["web_dl"] = f"https://store.steampowered.com/app/{steam}"
        j["steam"] = str(steam)
    if uri:
        j["uri"] = uri                    # protocolo del cliente instalado (sin navegador)
    if repo:
        j["repo"] = repo
        j["pat"] = pat or r"(?i)(win|windows).*\.(zip|exe)$"
    j.update(extra)
    return j


TIENDA = [
    # --- Emuladores (instalacion automatica) -------------------------------
    _j(CAT_EMU, "shadPS4 (PS4)",
       "Emulador de PS4. Se instala solo en la carpeta shadPS4. Requiere GPU con Vulkan y tus propios juegos.",
       "https://shadps4.net", "https://github.com/shadps4-emu/shadPS4/releases",
       repo="shadps4-emu/shadPS4",
       pats=[r"(?i)win64-qt.*\.zip$", r"(?i)win64-sdl.*\.zip$", r"(?i)win.*\.zip$"],
       emu="shadPS4"),

    _j(CAT_EMU, "PPSSPP (PSP)", "Emulador de PSP. Open source, multiplataforma.",
       "https://www.ppsspp.org", "https://github.com/hrydgard/ppsspp/releases",
       repo="hrydgard/ppsspp", pats=[r"(?i)PPSSPP.*Windows-x64\.zip$", r"(?i)Windows-x64\.zip$"],
       emu=os.path.join("emulators", "ppsspp")),
    _j(CAT_EMU, "DuckStation (PS1)", "Emulador de PlayStation 1. Precision y rendimiento.",
       "https://www.duckstation.org", "https://github.com/stenzek/duckstation/releases",
       repo="stenzek/duckstation",
       pats=[r"(?i)duckstation-windows-x64-release\.zip$", r"(?i)windows-x64.*\.zip$"],
       emu=os.path.join("emulators", "duckstation")),
    _j(CAT_EMU, "PCSX2 (PS2)", "Emulador de PlayStation 2. Viene en .7z (necesita py7zr o 7-Zip).",
       "https://pcsx2.net", "https://github.com/PCSX2/pcsx2/releases",
       repo="PCSX2/pcsx2", pats=[r"(?i)windows-x64-Qt\.7z$", r"(?i)windows-x64.*\.7z$"],
       emu=os.path.join("emulators", "pcsx2")),
    _j(CAT_EMU, "RPCS3 (PS3)", "Emulador de PlayStation 3. Viene en .7z (necesita py7zr o 7-Zip).",
       "https://rpcs3.net", "https://github.com/RPCS3/rpcs3-binaries-win/releases",
       repo="RPCS3/rpcs3-binaries-win", pats=[r"(?i)win64.*\.7z$"],
       emu=os.path.join("emulators", "rpcs3")),
    _j(CAT_EMU, "mGBA (GBA/GB)", "Emulador de Game Boy Advance / Color. Viene en .7z.",
       "https://mgba.io", "https://github.com/mgba-emu/mgba/releases",
       repo="mgba-emu/mgba", pats=[r"(?i)-win64\.7z$"],
       emu=os.path.join("emulators", "mGBA")),
    _j(CAT_EMU, "melonDS (NDS)", "Emulador de Nintendo DS. Open source.",
       "https://melonds.kuribo64.net", "https://github.com/melonDS-emu/melonDS/releases",
       repo="melonDS-emu/melonDS", pats=[r"(?i)windows-x86_64\.zip$"],
       emu=os.path.join("emulators", "melonDS")),
    _j(CAT_EMU, "Cemu (Wii U)", "Emulador de Wii U. Open source.",
       "https://cemu.info", "https://github.com/cemu-project/Cemu/releases",
       repo="cemu-project/Cemu", pats=[r"(?i)windows-x64\.zip$"],
       emu=os.path.join("emulators", "cemu")),
    _j(CAT_EMU, "Azahar (3DS)", "Sucesor activo de Citra. Emulador de Nintendo 3DS.",
       "https://azahar-emu.org", "https://github.com/azahar-emu/azahar/releases",
       repo="azahar-emu/azahar",
       pats=[r"(?i)azahar-windows-msvc-.*\.zip$", r"(?i)windows.*msvc.*\.zip$"],
       emu=os.path.join("emulators", "azahar")),
    _j(CAT_EMU, "Dolphin (GC/Wii)", "Emulador de GameCube y Wii. Se baja desde la web oficial (sin release en GitHub).",
       "https://dolphin-emu.org", "https://dolphin-emu.org/download/"),
    _j(CAT_EMU, "Eden (Switch)", "Emulador de Switch (linea Yuzu). Descarga manual desde la web oficial; sin firmware ni keys.",
       "https://eden-emu.dev", "https://eden-emu.dev"),   # TODO verificar: hosts inestables, sin asset hardcodeado

    # --- Tiendas (comprar / instalar con el cliente oficial, sin navegador) ---
    _j(CAT_TIENDAS, "Steam - Tienda", "Abre la tienda de Steam en el cliente. Compras e instalas ahi; los juegos aparecen solos en tu biblioteca.",
       "https://store.steampowered.com", uri="steam://store"),
    _j(CAT_TIENDAS, "Epic Games Store", "Abre la tienda de Epic en su launcher (muchos juegos gratis cada semana).",
       "https://store.epicgames.com", uri="com.epicgames.launcher://store"),
    _j(CAT_TIENDAS, "GOG Galaxy", "Juegos sin DRM. Abre GOG Galaxy. (protocolo NO VERIFICADO)",
       "https://www.gog.com", uri="goggalaxy://"),
    _j(CAT_TIENDAS, "Xbox / Microsoft Store", "Abre la tienda de Microsoft (Xbox, Game Pass PC). (protocolo NO VERIFICADO)",
       "https://www.xbox.com/games", uri="ms-windows-store://home"),

    # --- Carreras ----------------------------------------------------------
    _j("Carreras", "SuperTuxKart", "Carreras tipo Mario Kart. Hasta 4 jugadores local + online.",
       "https://supertuxkart.net", "https://supertuxkart.net/Download",
       repo="supertuxkart/stk-code"),
    _j("Carreras", "Trackmania (gratis)", "Carreras arcade contrarreloj. Version Starter gratuita.",
       "https://www.trackmania.com", steam=2225070),

    # --- Shooters ----------------------------------------------------------
    _j("Shooter", "Xonotic", "Shooter veloz tipo Quake. Split-screen y online.",
       "https://xonotic.org", "https://xonotic.org/download/"),
    _j("Shooter", "OpenArena", "Arena shooter estilo Quake III. Gratis y libre.",
       "https://openarena.ws", "https://openarena.ws/page.php?3"),
    _j("Shooter", "Red Eclipse", "FPS parkour con modos competitivos. Open source.",
       "https://www.redeclipse.net", "https://www.redeclipse.net/download"),
    _j("Shooter", "AssaultCube", "FPS ligero con multijugador. Corre en cualquier PC.",
       "https://assault.cubers.net", "https://assault.cubers.net/download.html"),
    _j("Shooter", "Cube 2: Sauerbraten", "FPS con editor de mapas en vivo. Open source.",
       "http://sauerbraten.org", "http://sauerbraten.org/"),
    _j("Shooter", "Unvanquished", "FPS de equipos: humanos vs alienigenas + construccion de base.",
       "https://unvanquished.net", "https://unvanquished.net/download/"),
    _j("Shooter", "GZDoom", "Motor moderno para Doom. Usa con Freedoom o tus WAD.",
       "https://zdoom.org", "https://zdoom.org/downloads",
       repo="ZDoom/gzdoom", pat=r"(?i)windows.*\.zip$"),
    _j("Shooter", "Freedoom", "Juego completo de Doom con arte y niveles libres.",
       "https://freedoom.github.io", "https://freedoom.github.io/download.html",
       repo="freedoom/freedoom", pat=r"(?i)^freedoom-\d[\d.]*\.zip$"),
    _j("Shooter", "Counter-Strike 2", "FPS tactico. Gratis en Steam.",
       "https://www.counter-strike.net", steam=730),
    _j("Shooter", "Team Fortress 2", "FPS por clases. Gratis.", "https://www.teamfortress.com", steam=440),
    _j("Shooter", "Apex Legends", "Battle royale por escuadras. Gratis.", "https://www.ea.com/games/apex-legends", steam=1172470),
    _j("Shooter", "The Finals", "Shooter por equipos con entornos destructibles. Gratis.", "https://www.reachthefinals.com", steam=2073850),
    _j("Shooter", "Marvel Rivals", "Hero shooter 6v6. Gratis.", "https://www.marvelrivals.com", steam=2767030),
    _j("Shooter", "Warframe", "Shooter cooperativo espacial. Gratis.", "https://www.warframe.com", "https://www.warframe.com/download"),
    _j("Shooter", "Destiny 2", "Shooter-looter online. Base gratis.", "https://www.destinythegame.com", steam=1085660),

    # --- Estrategia --------------------------------------------------------
    _j("Estrategia", "0 A.D.", "Estrategia historica RTS. Multijugador.",
       "https://play0ad.com", "https://play0ad.com/download/"),
    _j("Estrategia", "OpenRA", "Command & Conquer / Red Alert / Dune.",
       "https://www.openra.net", "https://www.openra.net/download/",
       repo="OpenRA/OpenRA", pat=r"(?i)(red.?alert|tiberian|dune).*x64.*\.exe$"),
    _j("Estrategia", "Battle for Wesnoth", "Estrategia por turnos. Local y online.",
       "https://www.wesnoth.org", "https://www.wesnoth.org/downloads/"),
    _j("Estrategia", "OpenTTD", "Transport Tycoon. Multijugador excelente.",
       "https://www.openttd.org", "https://www.openttd.org/downloads.html"),
    _j("Estrategia", "Warzone 2100", "RTS 3D. LAN y online.",
       "https://wz2100.net", "https://wz2100.net/download",
       repo="Warzone2100/warzone2100", pat=r"(?i)win.*x64.*\.exe$"),
    _j("Estrategia", "Mindustry", "Tower defense + automatizacion.",
       "https://mindustrygame.github.io", repo="Anuken/Mindustry", pat=r"(?i)windows.*\.zip$"),
    _j("Estrategia", "Unciv", "Clon de Civilization V ligero y open source.",
       "https://github.com/yairm210/Unciv", "https://github.com/yairm210/Unciv/releases",
       repo="yairm210/Unciv", pat=r"(?i)windows64.*\.zip$"),
    _j("Estrategia", "Widelands", "Estrategia tipo Settlers. Campanas y multijugador.",
       "https://www.widelands.org", "https://www.widelands.org/downloads/"),
    _j("Estrategia", "Freeciv", "Civilization libre. Local y online.",
       "https://www.freeciv.org", "https://www.freeciv.org/wiki/Download"),
    _j("Estrategia", "Simutrans", "Simulador de transporte, ligero y muy completo.",
       "https://www.simutrans.com", "https://www.simutrans.com/en/download/"),

    # --- Plataformas / Arcade ---------------------------------------------
    _j("Plataformas", "SuperTux", "Plataformas tipo Mario.",
       "https://www.supertux.org", "https://www.supertux.org/download.html",
       repo="SuperTux/supertux", pat=r"(?i)win.*\.(zip|exe)$"),
    _j("Plataformas", "DDNet", "Plataformas cooperativo online.",
       "https://ddnet.org", "https://ddnet.org/downloads/",
       repo="ddnet/ddnet", pat=r"(?i)win64.*\.zip$"),
    _j("Plataformas", "Teeworlds", "Shooter 2D multijugador, partidas rapidas.",
       "https://www.teeworlds.com", "https://www.teeworlds.com/?page=downloads",
       repo="teeworlds/teeworlds", pat=r"(?i)win64.*\.zip$"),
    _j("Plataformas", "Hedgewars", "Estilo Worms por turnos. Ideal para varios en la misma PC.",
       "https://www.hedgewars.org", "https://www.hedgewars.org/download.html"),
    _j("Plataformas", "Brawlhalla", "Peleas tipo Smash. Gratis.", "https://www.brawlhalla.com", steam=291550),
    _j("Plataformas", "Fall Guys", "Party game de obstaculos online. Gratis.", "https://www.fallguys.com", steam=1097150),

    # --- Aventura / RPG / Supervivencia ------------------------------------
    _j("Aventura/RPG", "Luanti (Minetest)", "Mundo de bloques open source.",
       "https://www.luanti.org", "https://www.luanti.org/downloads/",
       repo="luanti-org/luanti", pat=r"(?i)win64.*\.zip$"),
    _j("Aventura/RPG", "Veloren", "RPG de mundo abierto voxel, multijugador.",
       "https://veloren.net", "https://veloren.net/download/"),
    _j("Aventura/RPG", "Cataclysm: DDA", "Supervivencia roguelike profundo.",
       "https://cataclysmdda.org", "https://cataclysmdda.org/releases/"),
    _j("Aventura/RPG", "Dungeon Crawl Stone Soup", "Roguelike clasico, muy rejugable.",
       "https://crawl.develz.org", "https://crawl.develz.org/download.htm"),
    _j("Aventura/RPG", "Brogue CE", "Roguelike pulido, partidas cortas.",
       "https://github.com/tmewett/BrogueCE", "https://github.com/tmewett/BrogueCE/releases",
       repo="tmewett/BrogueCE", pat=r"(?i)win.*\.zip$"),
    _j("Aventura/RPG", "Shattered Pixel Dungeon", "Roguelike en pixel art. Open source.",
       "https://shatteredpixel.com", "https://shatteredpixel.com/#downloads"),
    _j("Aventura/RPG", "The Dark Mod", "Stealth tipo Thief. Totalmente gratis.",
       "https://www.thedarkmod.com", "https://www.thedarkmod.com/downloads/"),
    _j("Aventura/RPG", "Endless Sky", "Exploracion espacial y comercio, tipo Escape Velocity.",
       "https://endless-sky.github.io", "https://github.com/endless-sky/endless-sky/releases",
       repo="endless-sky/endless-sky", pat=r"(?i)win.*\.zip$"),
    _j("Aventura/RPG", "Pioneer Space Sim", "Simulador espacial de mundo abierto.",
       "https://pioneerspacesim.net", "https://pioneerspacesim.net/page/download/"),
    _j("Aventura/RPG", "ScummVM", "Aventuras graficas clasicas. Incluye juegos freeware (Beneath a Steel Sky, etc.).",
       "https://www.scummvm.org", "https://www.scummvm.org/downloads/"),
    _j("Aventura/RPG", "Path of Exile", "ARPG tipo Diablo. Gratis.", "https://pathofexile.com", steam=238960),
    _j("Aventura/RPG", "Lost Ark", "ARPG MMO. Gratis.", "https://www.playlostark.com", steam=1599340),

    # --- Otros free-to-play --------------------------------------------------
    _j("Free-to-play", "Dota 2", "MOBA. Gratis.", "https://www.dota2.com", steam=570),
    _j("Free-to-play", "War Thunder", "Simulacion de combate aereo/terrestre/naval. Gratis.", "https://warthunder.com", steam=236390),
    _j("Free-to-play", "PUBG: Battlegrounds", "Battle royale. Gratis.", "https://www.pubg.com", steam=578080),
    _j("Free-to-play", "Paladins", "Hero shooter por equipos. Gratis.", "https://www.paladins.com", steam=444090),
    _j("Free-to-play", "FlightGear", "Simulador de vuelo libre, muy realista.",
       "https://www.flightgear.org", "https://www.flightgear.org/download/"),
]

CATEGORIAS = [CAT_TODOS] + sorted({j["cat"] for j in TIENDA}, key=lambda c: (c != CAT_TIENDAS, c != CAT_EMU, c))


def filtrar(cat):
    """Lista de la tienda filtrada por categoria."""
    return TIENDA if cat == CAT_TODOS else [j for j in TIENDA if j["cat"] == cat]


def resolver(j):
    if j.get("dl"):
        return j["dl"]
    if not j.get("repo"):
        return None
    try:
        req = urllib.request.Request(
            f"https://api.github.com/repos/{j['repo']}/releases/latest",
            headers={"User-Agent": "MiConsola/5.1"}
        )
        rel = json.load(urllib.request.urlopen(req, timeout=15))
        pats = j.get("pats") or [j.get("pat", r".")]
        ass = []
        for pat in pats:                      # primer patron que encuentre algo gana
            ass = [a for a in rel.get("assets", []) if re.search(pat, a["name"])]
            if ass:
                break
        ass.sort(key=lambda a: (
            0 if a["name"].lower().endswith((".zip", ".7z", ".exe", ".msi")) else 1,
            0 if re.search(r"(?i)win|windows|x64|64", a["name"]) else 1,
            -a.get("size", 0)
        ))
        return ass[0]["browser_download_url"] if ass else None
    except Exception:
        return None


# El manejador de "--web" vive en main.py (no en este archivo).
_MAIN_PY = os.path.join(os.path.dirname(os.path.abspath(__file__)), "main.py")


def abrir_web(url):
    if not url:
        return
    try:
        import webview  # noqa
        proc = subprocess.Popen([sys.executable, _MAIN_PY, "--web", url])
        kiosk.game_launched(proc)   # modo consola: ceder el primer plano a la ventana web
        return
    except ImportError:
        pass
    kiosk.external_launched()       # navegador del sistema: sin proceso propio que vigilar
    if sys.platform == "win32":
        try:
            os.startfile(url)
            return
        except Exception:
            pass
    try:
        webbrowser.open(url, new=2)
    except Exception:
        try:
            if sys.platform == "win32":
                subprocess.Popen(["cmd", "/c", "start", "", url], shell=False)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", url])
            else:
                subprocess.Popen(["xdg-open", url])
        except Exception:
            pass


def pedir(j):
    """Devuelve 'tienda'|'web'|'descarga'|'error', o un mensaje de error para mostrar."""
    if j.get("uri"):                       # abrir el cliente de la tienda
        msg = abrir_uri(j["uri"])
        if msg:
            abrir_web(j.get("web_dl") or j["web"])     # sin cliente instalado: pagina oficial
            return "No esta el cliente de " + j["n"].split(" - ")[0] + ": abri su pagina oficial."
        return "tienda"
    if j.get("steam"):                     # free-to-play: pagina del juego dentro de Steam
        if not abrir_uri(f"steam://store/{j['steam']}"):
            return "tienda"
    if j.get("pago"):
        abrir_web(j.get("web") or "https://store.steampowered.com")
        return "web"
    url = resolver(j)
    if url and j.get("emu"):
        destino = os.path.join(BASE, j["emu"])
        ok = agregar_enlaces(url, "Emuladores", j["n"], destino=destino)
        return "descarga" if ok else "error"
    if url:
        ok = agregar_enlaces(url, "PC", j["n"])
        return "descarga" if ok else "error"
    destino = j.get("web_dl") or j.get("web")
    if destino:
        abrir_web(destino)
    return "web"
