"""
Menu del sistema (modo consola).

Se abre con Esc / B en la pantalla de inicio, o directamente en la pantalla de
PIN cuando se usa la combinacion secreta.

    Continuar
    Reiniciar el equipo        (pide confirmacion)
    Apagar el equipo           (pide confirmacion)
    Salir al escritorio de Windows   (pide PIN de 4 digitos)

Se maneja con las mismas acciones logicas que el resto del launcher
("a", "b", "i", "d", "ok", "atras"), asi que funciona con teclado y mando.
En el PIN tambien se pueden teclear los digitos directamente.
"""
from __future__ import annotations

import time
from typing import List, Optional, Tuple

import pygame

from config import PANEL, PANEL2, TEXTO, SUAVE, AZUL, ROJO, DORADO, VERDE
from consoleos.settings import DEFAULT_PIN, PIN_LENGTH

_MAX_FAILS = 5
_LOCK_SECONDS = 30


class SystemMenu:
    def __init__(self, kiosk, f_tit, f_med, f_peq, f_mini) -> None:
        self._kiosk = kiosk
        self._f_tit, self._f_med, self._f_peq, self._f_mini = f_tit, f_med, f_peq, f_mini

        self.visible = False
        self.should_quit = False          # main.py cierra el launcher cuando es True

        self._view = "menu"               # "menu" | "confirm" | "pin"
        self._sel = 0
        self._pending: Optional[str] = None     # accion a confirmar
        self._confirm_sel = 1                   # 0 = Si, 1 = No (por defecto No)
        self._digits: List[int] = [0] * PIN_LENGTH
        self._pos = 0
        self._message = ""
        self._fails = 0
        self._locked_until = 0.0
        self._back_closes = False               # se abrio directo en PIN: "atras" cierra todo
        self._dim: Optional[pygame.Surface] = None

    # ------------------------------------------------------------- apertura
    def open(self, pin_direct: bool = False) -> None:
        self.visible = True
        self._message = ""
        self._back_closes = pin_direct
        if pin_direct:
            self._start_pin()
        else:
            self._view = "menu"
            self._sel = 0
        self._kiosk.set_overlay(True)

    def close(self) -> None:
        if not self.visible:
            return
        self.visible = False
        self._kiosk.set_overlay(False)

    def _items(self) -> List[Tuple[str, str]]:
        items = [("Continuar", "continue"),
                 ("Reiniciar el equipo", "restart"),
                 ("Apagar el equipo", "shutdown")]
        settings = self._kiosk.settings
        if settings is not None and settings.allow_exit_to_desktop:
            items.append(("Salir al escritorio de Windows", "desktop"))
        return items

    def _start_pin(self) -> None:
        self._view = "pin"
        self._digits = [0] * PIN_LENGTH
        self._pos = 0

    # ---------------------------------------------------------------- entrada
    def handle_key(self, event) -> bool:
        """Teclas crudas: digitos en la pantalla de PIN. True si se consumio."""
        if self._view != "pin" or event.type != pygame.KEYDOWN:
            return False
        key = event.key
        digit = None
        if pygame.K_0 <= key <= pygame.K_9:
            digit = key - pygame.K_0
        elif pygame.K_KP0 <= key <= pygame.K_KP9:
            digit = key - pygame.K_KP0
        if digit is not None:
            self._digits[self._pos] = digit
            self._pos = min(self._pos + 1, PIN_LENGTH - 1)
            return True
        if key == pygame.K_BACKSPACE:
            self._pos = max(0, self._pos - 1)
            return True
        return False

    def handle_action(self, accion: str) -> None:
        if not self.visible:
            return
        if self._view == "menu":
            self._action_menu(accion)
        elif self._view == "confirm":
            self._action_confirm(accion)
        else:
            self._action_pin(accion)

    def _action_menu(self, accion: str) -> None:
        items = self._items()
        if accion == "a":
            self._sel = (self._sel - 1) % len(items)
        elif accion == "b":
            self._sel = (self._sel + 1) % len(items)
        elif accion == "atras":
            self.close()
        elif accion == "ok":
            code = items[self._sel][1]
            if code == "continue":
                self.close()
            elif code in ("restart", "shutdown"):
                self._pending, self._confirm_sel, self._view = code, 1, "confirm"
            elif code == "desktop":
                self._start_pin()
                self._message = ""

    def _action_confirm(self, accion: str) -> None:
        if accion in ("a", "b", "i", "d"):
            self._confirm_sel = 1 - self._confirm_sel
        elif accion == "atras":
            self._view = "menu"
        elif accion == "ok":
            if self._confirm_sel == 0 and self._pending:
                if self._kiosk.power(self._pending):
                    self.should_quit = True
                    self.close()
                else:
                    self._view = "menu"
                    self._message = "No se pudo ejecutar la accion."
            else:
                self._view = "menu"

    def _action_pin(self, accion: str) -> None:
        if accion == "a":
            self._digits[self._pos] = (self._digits[self._pos] + 1) % 10
        elif accion == "b":
            self._digits[self._pos] = (self._digits[self._pos] - 1) % 10
        elif accion == "i":
            self._pos = max(0, self._pos - 1)
        elif accion == "d":
            self._pos = min(PIN_LENGTH - 1, self._pos + 1)
        elif accion == "atras":
            if self._back_closes:
                self.close()
            else:
                self._view = "menu"
        elif accion == "ok":
            if self._pos < PIN_LENGTH - 1:
                self._pos += 1
            else:
                self._submit_pin()

    def _submit_pin(self) -> None:
        now = time.time()
        if now < self._locked_until:
            self._message = f"Demasiados intentos. Espera {int(self._locked_until - now) + 1} s."
            return
        pin = "".join(str(d) for d in self._digits)
        settings = self._kiosk.settings
        if settings is not None and settings.verify_pin(pin):
            self._fails = 0
            if self._kiosk.exit_to_desktop():
                self.should_quit = True
                self.close()
            else:
                self._message = "Salir al escritorio esta desactivado."
                self._start_pin()
            return
        self._fails += 1
        self._start_pin()
        if self._fails >= _MAX_FAILS:
            self._fails = 0
            self._locked_until = now + _LOCK_SECONDS
            self._message = f"Demasiados intentos. Espera {_LOCK_SECONDS} s."
        else:
            self._message = f"PIN incorrecto ({_MAX_FAILS - self._fails} intentos restantes)"

    # ----------------------------------------------------------------- dibujo
    def _text(self, surf, font, color, text, center=None, topleft=None) -> None:
        img = font.render(str(text), True, color)
        if center is not None:
            surf.blit(img, img.get_rect(center=center))
        else:
            surf.blit(img, topleft)

    def draw(self, surf: pygame.Surface) -> None:
        if not self.visible:
            return
        sw, sh = surf.get_size()
        if self._dim is None or self._dim.get_size() != (sw, sh):
            self._dim = pygame.Surface((sw, sh), pygame.SRCALPHA)
            self._dim.fill((0, 0, 0, 190))
        surf.blit(self._dim, (0, 0))

        panel = pygame.Rect(0, 0, 640, 440)
        panel.center = (sw // 2, sh // 2)
        pygame.draw.rect(surf, PANEL, panel, border_radius=16)
        pygame.draw.rect(surf, AZUL, panel, 2, border_radius=16)
        self._text(surf, self._f_tit, TEXTO, "Sistema", center=(panel.centerx, panel.y + 44))

        if self._view == "menu":
            self._draw_menu(surf, panel)
        elif self._view == "confirm":
            self._draw_confirm(surf, panel)
        else:
            self._draw_pin(surf, panel)

    def _draw_menu(self, surf, panel) -> None:
        for i, (label, code) in enumerate(self._items()):
            r = pygame.Rect(panel.x + 40, panel.y + 90 + i * 62, panel.w - 80, 52)
            sel = i == self._sel
            pygame.draw.rect(surf, PANEL2 if sel else PANEL, r, border_radius=10)
            if sel:
                pygame.draw.rect(surf, AZUL, r, 2, border_radius=10)
            color = ROJO if code in ("shutdown",) and sel else (DORADO if code == "desktop" and sel else TEXTO)
            self._text(surf, self._f_med, color, label, center=r.center)
        if self._message:
            self._text(surf, self._f_peq, ROJO, self._message, center=(panel.centerx, panel.bottom - 56))
        self._text(surf, self._f_mini, SUAVE, "Flechas mover   Enter elegir   Esc volver",
                   center=(panel.centerx, panel.bottom - 24))

    def _draw_confirm(self, surf, panel) -> None:
        pregunta = "¿Reiniciar el equipo?" if self._pending == "restart" else "¿Apagar el equipo?"
        self._text(surf, self._f_med, TEXTO, pregunta, center=(panel.centerx, panel.y + 150))
        for i, label in enumerate(("Sí", "No")):
            r = pygame.Rect(0, 0, 200, 56)
            r.center = (panel.centerx + (-120 if i == 0 else 120), panel.y + 250)
            sel = i == self._confirm_sel
            pygame.draw.rect(surf, PANEL2 if sel else PANEL, r, border_radius=10)
            pygame.draw.rect(surf, VERDE if sel else SUAVE, r, 2, border_radius=10)
            self._text(surf, self._f_med, TEXTO, label, center=r.center)
        self._text(surf, self._f_mini, SUAVE, "Izquierda/derecha elegir   Enter confirmar   Esc cancelar",
                   center=(panel.centerx, panel.bottom - 24))

    def _draw_pin(self, surf, panel) -> None:
        self._text(surf, self._f_med, TEXTO, "Introduce el PIN para salir al escritorio",
                   center=(panel.centerx, panel.y + 110))
        box_w, gap = 74, 22
        total = PIN_LENGTH * box_w + (PIN_LENGTH - 1) * gap
        x0 = panel.centerx - total // 2
        y = panel.y + 170
        for i, d in enumerate(self._digits):
            r = pygame.Rect(x0 + i * (box_w + gap), y, box_w, 90)
            sel = i == self._pos
            pygame.draw.rect(surf, PANEL2 if sel else PANEL, r, border_radius=10)
            pygame.draw.rect(surf, DORADO if sel else SUAVE, r, 3 if sel else 1, border_radius=10)
            self._text(surf, self._f_tit, TEXTO, d, center=r.center)
            if sel:
                cx = r.centerx
                pygame.draw.polygon(surf, DORADO, [(cx - 9, y - 8), (cx + 9, y - 8), (cx, y - 18)])
                pygame.draw.polygon(surf, DORADO, [(cx - 9, y + 98), (cx + 9, y + 98), (cx, y + 108)])
        if self._message:
            self._text(surf, self._f_peq, ROJO, self._message, center=(panel.centerx, panel.y + 318))
        settings = self._kiosk.settings
        if settings is not None and settings.uses_default_pin():
            self._text(surf, self._f_mini, DORADO,
                       f"Aviso: sigues usando el PIN por defecto ({DEFAULT_PIN}). Cambialo con tools\\cambiar_pin.bat",
                       center=(panel.centerx, panel.y + 352))
        self._text(surf, self._f_mini, SUAVE,
                   "Arriba/abajo cambiar digito   Izq/der mover   Enter confirmar   Esc volver",
                   center=(panel.centerx, panel.bottom - 24))
