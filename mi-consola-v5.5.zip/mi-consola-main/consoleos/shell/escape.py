"""
Combinacion secreta de salida.

* HoldTrigger   : dispara un callback si una condicion se mantiene N segundos.
* parse_combo   : convierte ["ctrl", "shift", "f12"] en codigos de tecla virtual.
* PadCombo      : detecta la combinacion de botones del mando (p. ej. Select+Start+L1+R1).

La combinacion de teclado la evalua keyhook.py dentro del hook global, asi
responde aunque un emulador tenga el foco. La del mando se alimenta desde el
bucle de eventos de pygame (con SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS activo, el
mando se sigue leyendo aunque el juego este en primer plano).

El callback se ejecuta en un hilo temporal: solo debe publicar un evento de
pygame (que es thread-safe), nunca tocar la interfaz directamente.
"""
from __future__ import annotations

import threading
from typing import Callable, Dict, FrozenSet, Iterable, Optional, Set

import pygame

from consoleos.log import get_logger
from consoleos.shell import winapi

log = get_logger("escape")

_MODIFIERS = {
    "ctrl": winapi.VK_CONTROL, "control": winapi.VK_CONTROL,
    "shift": winapi.VK_SHIFT,
    "alt": winapi.VK_MENU,
}
_NAMED = {
    "esc": 0x1B, "escape": 0x1B, "tab": 0x09, "pause": 0x13,
    "pageup": 0x21, "pagedown": 0x22, "end": 0x23, "home": 0x24,
    "insert": 0x2D, "delete": 0x2E,
}


def parse_combo(names: Iterable[str]) -> FrozenSet[int]:
    """Nombres de tecla -> conjunto de VK. Lanza ValueError si hay un nombre desconocido."""
    result: Set[int] = set()
    for raw in names:
        n = str(raw).strip().lower()
        if n in _MODIFIERS:
            result.add(_MODIFIERS[n])
        elif n in _NAMED:
            result.add(_NAMED[n])
        elif len(n) >= 2 and n[0] == "f" and n[1:].isdigit() and 1 <= int(n[1:]) <= 12:
            result.add(0x6F + int(n[1:]))          # F1 = 0x70
        elif len(n) == 1 and n.isalnum():
            result.add(ord(n.upper()))             # A-Z y 0-9 coinciden con su VK
        else:
            raise ValueError(f"Tecla desconocida en la combinacion: {raw!r}")
    if not result:
        raise ValueError("La combinacion esta vacia")
    return frozenset(result)


class HoldTrigger:
    """Dispara `callback` si `update(True)` se mantiene `hold_seconds` sin interrupcion."""

    def __init__(self, hold_seconds: float, callback: Callable[[], None],
                 verify: Optional[Callable[[], bool]] = None) -> None:
        self._hold = max(0.5, float(hold_seconds))
        self._callback = callback
        self._verify = verify              # confirmacion final: la combinacion sigue pulsada
        self._timer: Optional[threading.Timer] = None
        self._latched = False              # ya disparo; no repetir hasta soltar
        self._lock = threading.Lock()

    def update(self, active: bool) -> None:
        with self._lock:
            if active:
                if self._timer is None and not self._latched:
                    self._timer = threading.Timer(self._hold, self._fire)
                    self._timer.daemon = True
                    self._timer.start()
            else:
                self._latched = False
                if self._timer is not None:
                    self._timer.cancel()
                    self._timer = None

    def cancel(self) -> None:
        self.update(False)

    def _fire(self) -> None:
        with self._lock:
            self._timer = None
            if self._verify is not None and not self._verify():
                return
            self._latched = True
        try:
            self._callback()
        except Exception:
            log.exception("Error en el callback de la combinacion secreta")


class PadCombo:
    """Detecta una combinacion de botones de mando mantenida (por mando)."""

    def __init__(self, buttons: Iterable[int], trigger: HoldTrigger) -> None:
        self._required: FrozenSet[int] = frozenset(int(b) for b in buttons)
        self._trigger = trigger
        self._pressed: Dict[int, Set[int]] = {}

    def feed(self, event: "pygame.event.Event") -> None:
        t = event.type
        if t in (pygame.JOYBUTTONDOWN, pygame.JOYBUTTONUP):
            jid = getattr(event, "instance_id", getattr(event, "joy", 0))
            pressed = self._pressed.setdefault(jid, set())
            if t == pygame.JOYBUTTONDOWN:
                pressed.add(event.button)
            else:
                pressed.discard(event.button)
        elif t == pygame.JOYDEVICEREMOVED:
            self._pressed.pop(getattr(event, "instance_id", None), None)
        else:
            return
        self._trigger.update(self.is_active())

    def is_active(self) -> bool:
        if not self._required:
            return False
        return any(self._required <= s for s in list(self._pressed.values()))
