"""
Configuracion de Mi Consola OS (consoleos.json).

Se guarda junto al resto de configuraciones: <BASE>\\consoleos.json
Si el archivo no existe se crea con los valores por defecto. Los valores
invalidos se ignoran (se usa el por defecto) para que un JSON mal editado
nunca impida arrancar la consola.

PIN
---
El PIN protege la salida al escritorio de Windows. Son 4 digitos. Se guarda
como hash PBKDF2-SHA256 con sal aleatoria, nunca en claro. Mientras no se
cambie, el PIN es 0000 (la interfaz lo avisa).

Uso por linea de comandos:
    python -m consoleos.settings show
    python -m consoleos.settings set-pin
    python -m consoleos.settings reset-pin
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import sys
from dataclasses import asdict, dataclass, field, fields
from typing import List, Optional

from config import BASE
from consoleos.log import get_logger

log = get_logger("settings")

SETTINGS_PATH = os.path.join(BASE, "consoleos.json")
DEFAULT_PIN = "0000"
PIN_LENGTH = 4
_PBKDF2_ROUNDS = 120_000


def _hash_pin(pin: str, salt_hex: str) -> str:
    return hashlib.pbkdf2_hmac(
        "sha256", pin.encode("utf-8"), bytes.fromhex(salt_hex), _PBKDF2_ROUNDS
    ).hex()


@dataclass
class Settings:
    # Modo por defecto cuando no se pasa --mode: "normal" o "console".
    mode: str = "normal"

    # Capa 1 - Shell / Kiosk
    hide_taskbar: bool = True
    block_keys: bool = True
    force_topmost: bool = True
    allow_altf4_in_games: bool = True   # Alt+F4 sigue cerrando juegos/emuladores
    allow_exit_to_desktop: bool = True

    # Combinacion secreta (se mantiene pulsada escape_hold_seconds).
    escape_keys: List[str] = field(default_factory=lambda: ["ctrl", "shift", "f12"])
    escape_pad_buttons: List[int] = field(default_factory=lambda: [4, 5, 6, 7])
    escape_hold_seconds: float = 3.0

    # PIN (hash + sal). Vacio = PIN por defecto.
    pin_salt: str = ""
    pin_hash: str = ""

    # ------------------------------------------------------------------ PIN
    def uses_default_pin(self) -> bool:
        return not (self.pin_hash and self.pin_salt)

    def verify_pin(self, pin: str) -> bool:
        pin = str(pin or "")
        if self.uses_default_pin():
            return hmac.compare_digest(pin, DEFAULT_PIN)
        try:
            return hmac.compare_digest(_hash_pin(pin, self.pin_salt), self.pin_hash)
        except ValueError:
            return False

    def set_pin(self, pin: str) -> None:
        if not re.fullmatch(r"\d{%d}" % PIN_LENGTH, str(pin or "")):
            raise ValueError(f"El PIN debe tener exactamente {PIN_LENGTH} digitos.")
        self.pin_salt = os.urandom(16).hex()
        self.pin_hash = _hash_pin(pin, self.pin_salt)

    def reset_pin(self) -> None:
        self.pin_salt = ""
        self.pin_hash = ""

    # ------------------------------------------------------------ persistencia
    @classmethod
    def load(cls, path: Optional[str] = None) -> "Settings":
        path = path or SETTINGS_PATH
        s = cls()
        if os.path.exists(path):
            try:
                with open(path, encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    s._apply(data)
                else:
                    log.warning("consoleos.json no contiene un objeto; uso valores por defecto")
            except (OSError, ValueError) as e:
                log.warning("No se pudo leer %s (%s); uso valores por defecto", path, e)
        else:
            s.save(path)
        s._sanitize()
        return s

    def save(self, path: Optional[str] = None) -> bool:
        path = path or SETTINGS_PATH
        tmp = path + ".tmp"
        try:
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(asdict(self), f, indent=2, ensure_ascii=False)
            os.replace(tmp, path)
            return True
        except OSError as e:
            log.warning("No se pudo guardar %s: %s", path, e)
            try:
                os.remove(tmp)
            except OSError:
                pass
            return False

    # --------------------------------------------------------------- internos
    def _apply(self, data: dict) -> None:
        for f in fields(self):
            if f.name not in data:
                continue
            current, value = getattr(self, f.name), data[f.name]
            if isinstance(current, bool):
                ok = isinstance(value, bool)
            elif isinstance(current, float):
                ok = isinstance(value, (int, float)) and not isinstance(value, bool)
                value = float(value) if ok else value
            elif isinstance(current, int):
                ok = isinstance(value, int) and not isinstance(value, bool)
            elif isinstance(current, str):
                ok = isinstance(value, str)
            elif isinstance(current, list):
                ok = isinstance(value, list)
            else:
                ok = False
            if ok:
                setattr(self, f.name, value)
            else:
                log.warning("Valor invalido para '%s' en consoleos.json; uso el por defecto", f.name)

    def _sanitize(self) -> None:
        self.escape_hold_seconds = min(10.0, max(1.0, float(self.escape_hold_seconds)))
        self.escape_keys = [str(k) for k in self.escape_keys if isinstance(k, str)]
        self.escape_pad_buttons = [
            b for b in self.escape_pad_buttons
            if isinstance(b, int) and not isinstance(b, bool) and b >= 0
        ]
        if self.pin_hash:
            try:
                bytes.fromhex(self.pin_salt)
            except ValueError:
                log.warning("Sal del PIN corrupta; se restaura el PIN por defecto")
                self.reset_pin()


# ------------------------------------------------------------------------ CLI
def _cli(argv: List[str]) -> int:
    import getpass

    cmd = argv[0] if argv else "show"
    s = Settings.load()

    if cmd == "show":
        data = asdict(s)
        data["pin_salt"] = "***" if s.pin_salt else ""
        data["pin_hash"] = "***" if s.pin_hash else ""
        print(f"Archivo: {SETTINGS_PATH}")
        print(json.dumps(data, indent=2, ensure_ascii=False))
        if s.uses_default_pin():
            print(f"\nAviso: usas el PIN por defecto ({DEFAULT_PIN}). Cambialo con 'set-pin'.")
        return 0

    if cmd == "set-pin":
        a = getpass.getpass(f"Nuevo PIN ({PIN_LENGTH} digitos): ")
        b = getpass.getpass("Repite el PIN: ")
        if a != b:
            print("Los PIN no coinciden. No se cambio nada.")
            return 1
        try:
            s.set_pin(a)
        except ValueError as e:
            print(e)
            return 1
        print("PIN actualizado." if s.save() else "No se pudo guardar el archivo.")
        return 0

    if cmd == "reset-pin":
        s.reset_pin()
        print(f"PIN restaurado a {DEFAULT_PIN}." if s.save() else "No se pudo guardar el archivo.")
        return 0

    print("Uso: python -m consoleos.settings [show | set-pin | reset-pin]")
    return 2


if __name__ == "__main__":
    sys.exit(_cli(sys.argv[1:]))
